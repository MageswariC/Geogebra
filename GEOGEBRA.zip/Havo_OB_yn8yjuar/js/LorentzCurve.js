var LorentzCurve = function(){
	
	var that = this;	
	that.isIPAD = (/iPad|iPhone/i.test(navigator.userAgent));
	that.isAndroid = navigator.userAgent.toLowerCase().indexOf("android") > -1; 
	that.canvasWidth = 960;
	that.canvasHeight = 599;	
	that.C1 = -0.37;
	that.isMouseDown = false;
	that.isBlueLineHighLightRequired = false; 
	that.isBlueCircleHighLightRequired = false; 
	that.isYellowCircleHighLightRequired = false;
	that.yellowCircleIndex = null;
	that.isFullScreenEnabled = false;
	that.Y1 = that._Y1 = 0;
	that.X1 = that._X1 = 0;
	that.diffX = that._diffX = 0;
	that.diffY = that._diffY = 0;
	that.x1 = 0;
	that.y1 = 0;
	that.marginL = 0;
	that.marginR = 0;
	that.marginT = 0;
	that.marginB = 0;
	that.totalWidth = 0;
	that.totalHeight = 0;
	that.availWidth = that.totalWidth - that.marginL - that.marginR;
	that.availHeight = that.totalHeight - that.marginT - that.marginB;
	that.isLineMoved = false;
	that.blueLegendCircleObj = {};
	that.orangeLegendCircleObj = {};
	that.slider = {mousedown:false};
	that.knob = {};
		
	this.init = function(){
		that.gCanvas = document.getElementById("graphCanvas");
		that.gCanvasContext = that.gCanvas.getContext('2d');
		
		//alert(that.isAndroid);
		
		if(that.isIPAD || that.isAndroid){
			$(that.gCanvas).off('touchstart').on('touchstart',that.onCanvasMouseDown);
			$(that.gCanvas).off('touchend').on('touchend',that.onCanvasMouseUp);
			$(that.gCanvas).off('touchmove').on('touchmove',that.onCanvasMouseMove);
			$("#fullScreenBtn").hide();
		}else{
			$(that.gCanvas).off('mousedown').on('mousedown',that.onCanvasMouseDown);
			$(document).off('mouseup').on('mouseup',that.onCanvasMouseUp);
			$(that.gCanvas).off('mousemove').on('mousemove',that.onCanvasMouseMove);
			$("#fullScreenBtn").show();
		}
		
		$("#resetBtn").off('click').on('click',that.onResetBtnClick);
		$("#fullScreenBtn").off('click').on('click',that.openFullscreen);
		
		$("#fullScreenBtn").off('mouseover').on('mouseover',that.onBtnMouseOver);
		$("#fullScreenBtn").off('mouseout').on('mouseout',that.onBtnMouseOut);
				
		document.addEventListener("fullscreenchange",that.onActivityFullScreen);
		document.addEventListener("mozfullscreenchange",that.onActivityFullScreen);
		document.addEventListener("webkitfullscreenchange",that.onActivityFullScreen);
		document.addEventListener("MSFullscreenChange",that.onActivityFullScreen);
		
		$("#canvasSliderKnob").off('focus').on('focus',that.onKnobFocus);
		$("#canvasSliderKnob").off('blur').on('blur',that.onKnobBlur);
		
		$(document).off('keydown').on('keydown',that.onDocumentKeyDown);
		
		$("#exitScreenImage").hide();

		that.initSlider();
		that.setCanvasSize();
		
	}
	
	this.onDocumentKeyDown = function(e){
		console.log(e.keyCode+" "+that.isKnobFocused);
		
		if(that.isKnobFocused){
			if(e.keyCode == 38){
				that.onKnobMove(that.knob.y-1);
			}else if(e.keyCode == 40){
				that.onKnobMove(that.knob.y+1);
			}
		}
	}
	
	this.onKnobFocus = function(){
		that.isKnobFocused = true;
		that.drawCanvas();
	}
	
	this.onKnobBlur = function(){
		that.isKnobFocused = false;	
		that.drawCanvas();
	}
	
	this.onBtnMouseOver = function(){
		$("#fullScreenBtn").css({backgroundColor:"#eee"});	
		$("#fullScreenBtn img").css({opacity:1});	
	}
	
	this.onBtnMouseOut = function(){
		$("#fullScreenBtn").css({background:"#fff"});	
		$("#fullScreenBtn img").css({opacity:0.5});			
	}
	
	
	this.onActivityFullScreen = function(){
		if ( document.fullscreenElement || document.webkitFullscreenElement || document.mozFullScreenElement || document.msFullscreenElement ) {
			 $("#fullScreenImage").hide();
			  $("#exitScreenImage").show();
				
			that.isFullScreenEnabled  = true;	
			that.setCanvasSize();
			
		}else{
			$("#fullScreenImage").show();
			$("#exitScreenImage").hide();

			that.isFullScreenEnabled  = false;	
			that.setCanvasSize();
			
		}
	}
	
	this.initSlider = function(){
		$("#valSlider").slider({
								orientation : "vertical",
								min : 0.01,
								max :2.5,
								step : 0.01,
								start : function(e,ui){
									var curBottom =  $("#valSlider span").css('bottom').replace("px","") - ( $("#valSlider .slider_knob_bg").height() - $("#valSlider span").height() )/2 - 2;
									$("#valSlider .slider_knob_bg").css({'width':'24px','height':'24px','border-radius':'24px','left':-(9)+'px','bottom':curBottom+'px'});									
								},
								change : function(e,ui){
									var curBottom =  $("#valSlider span").css('bottom').replace("px","") - ( $("#valSlider .slider_knob_bg").height() - $("#valSlider span").height() )/2;
									$("#valSlider .slider_knob_bg").css({bottom:curBottom+"px"});
									
								},
								slide : function(e,ui){
									that.C1 = -1 * (2.5-ui.value);
									that.drawCanvas();
									console.log(2.5-ui.value);	
									
									var curBottom =  $("#valSlider span").css('bottom').replace("px","") - ( $("#valSlider .slider_knob_bg").height() - $("#valSlider span").height() )/2 - 1;
									$("#valSlider .slider_knob_bg").css({bottom:curBottom+"px"});
								},
								stop : function(e,ui){
									that.C1 = -1 * (2.5-ui.value);
									that.drawCanvas();
									console.log(2.5-ui.value);		
									
									$("#valSlider .slider_knob_bg").css({'width':'20px','height':'20px','border-radius':'20px','left':-(7)+'px'});	
									
									var curBottom =  $("#valSlider span").css('bottom').replace("px","") - ( $("#valSlider .slider_knob_bg").height() - $("#valSlider span").height() )/2;
									$("#valSlider .slider_knob_bg").css({bottom:curBottom+"px"});
								}
		});	
		
		$("#valSlider").slider({value: (2.5-0.37) });
		$("#valSlider span").append( $("#slider_val_label") );
		
		var curBottom =  $("#valSlider span").css('bottom').replace("px","") - ( $("#valSlider .slider_knob_bg").height() - $("#valSlider span").height() )/2;
		$("#valSlider .slider_knob_bg").css({bottom:curBottom+"px"});
	}
	
	
	this.onResetBtnClick = function(){
		that.C1 = -0.37;
		that.isMouseDown = false;
		that.isBlueLineHighLightRequired = false; 
		that.isBlueCircleHighLightRequired = false; 
		that.isYellowCircleHighLightRequired = false;
		that.yellowCircleIndex = null;	
		//$("#valSlider").slider({value: (2.5-0.37) });
		that.knob.y = ( that.knob.yMin + ( Math.abs(that.C1) / ( (2.5-0.01) / (that.knob.yMax - that.knob.yMin)  ) ) ).toFixed(2);
		that.knob.y = Number(that.knob.y);
		that.drawCanvas();
	}
	
	this.onCanvasMouseDown = function(e){
		
		e.preventDefault();
		
		var touch = e.originalEvent && e.originalEvent.touches && e.originalEvent.touches[0];
		e = touch || e;
		
		var mouseX = e.pageX - $(that.gCanvas).offset().left;
		var mouseY = e.pageY - $(that.gCanvas).offset().top;
		
		//that.diffX = 0;
		//that.diffY = 0;
		
		//console.log(mouseX,mouseY);
		
		that.isBlueLineHighLightRequired = false;
		that.isBlueCircleHighLightRequired = false;
		that.isYellowCircleHighLightRequired = false;
		that.blueLegendCircleObj.isHighLightRequired = false;
		that.orangeLegendCircleObj.isHighLightRequired = false;
		that.yellowCircleIndex = null;
		that.isKnobFocused = false;
		that.slider.mousedown = false;	
		
		for(var i=0;i<that.lineDots.length;i++){
			var xMin = that.lineDots[i].x-5;
			var xMax = that.lineDots[i].x+5;
			
			var yMin =  that.lineDots[i].y-5;
			var yMax =  that.lineDots[i].y+5;
			
			if( (mouseX > xMin) && (mouseX < xMax) && (mouseY > yMin) && (mouseY < yMax) ){
				console.log('CIRCLE HIT!!!!!');
				that.isBlueCircleHighLightRequired = true;
			}
		}
		
		
		for(var i=0;i<that.circleDots.length;i++){
			var xMin = that.circleDots[i].x-5;
			var xMax = that.circleDots[i].x+5;
			
			var yMin =  that.circleDots[i].y-5;
			var yMax =  that.circleDots[i].y+5;
			
			if( (mouseX > xMin) && (mouseX < xMax) && (mouseY > yMin) && (mouseY < yMax) ){
				console.log('CIRCLE HIT!!!!!');
				that.isYellowCircleHighLightRequired = true;
				that.yellowCircleIndex = that.circleDots[i].index;
			}
		}
		
		
		var xMin = that.orangeLegendCircleObj.x-5;
		var xMax = that.orangeLegendCircleObj.x+5;
		
		var yMin =  that.orangeLegendCircleObj.y-5;
		var yMax =  that.orangeLegendCircleObj.y+5;
		
		if( (mouseX > xMin) && (mouseX < xMax) && (mouseY > yMin) && (mouseY < yMax) ){
				console.log('CIRCLE HIT!!!!!');
				that.orangeLegendCircleObj.isHighLightRequired = true;
		}
		
		var xMin = that.blueLegendCircleObj.x-5;
		var xMax = that.blueLegendCircleObj.x+5;
		
		var yMin =  that.blueLegendCircleObj.y-5;
		var yMax =  that.blueLegendCircleObj.y+5;
		
		if( (mouseX > xMin) && (mouseX < xMax) && (mouseY > yMin) && (mouseY < yMax) ){
				console.log('CIRCLE HIT!!!!!');
				that.blueLegendCircleObj.isHighLightRequired = true;
		}
		
		that.isPointOnLine(mouseX,mouseY);
		
		var xKnobMin = that.knob.x-(that.sliderKnobRadius);
		var xknobMax = that.knob.x+(that.sliderKnobRadius) + (that.canvasWidth/40) + that.gCanvasContext.measureText("Bolling oranje lijn").width;
		
		var yKnobMin = that.knob.y-(that.sliderKnobRadius);
		var yknobMax = that.knob.y+(that.sliderKnobRadius);
		
		//console.log(xKnobMin+" "+xknobMax+" "+yKnobMin+" "+yknobMax);
		
		if( (mouseX > xKnobMin) && (mouseX < xknobMax) && (mouseY > yKnobMin) && (mouseY < yknobMax) ){
			that.slider.mousedown = true;	
			that.isKnobFocused = true;
			console.log('Knob Hit');
		}
		
		that.drawCanvas();
	}
	
	this.isPointOnLine = function(curX,curY){
		var  gridX =  ( curX - that.marginL ) / that.xUnitWidth;
		var  gridY =  ( (that.marginT+that.availHeight) - curY ) / that.yUnitWidth;
		
		var gridX = gridX.toFixed(1);
		var gridY = gridY.toFixed(1);
		
		var LHS = gridY - that.Y1; 
		var RHS = gridX - that.X1; 
		
		console.log(that.Y1,that.X1);
		
		that.clickedX =  curX;
		that.clickedY =  curY;
		
		var diff = Math.abs(LHS - RHS).toFixed(1);
		
		if(that.isIPAD || that.isAndroid){
			var toleranceValue = 0.5;
		}else{
			var toleranceValue = 0.1;
		}
		
		if(diff <= toleranceValue){
			console.log("POINT IS ON THE LINE");
			that.isMouseDown = true;
			that.isBlueLineHighLightRequired = true;		
		}
		
		that.drawCanvas();
	}
	
	this.onCanvasMouseMove = function(e){
		
		e.preventDefault();
		
		var touch = e.originalEvent && e.originalEvent.touches && e.originalEvent.touches[0];
		e = touch || e;
		
		var mouseX = e.pageX - $(that.gCanvas).offset().left;
		var mouseY = e.pageY - $(that.gCanvas).offset().top;
		
		var xKnobMin = that.knob.x-(that.sliderKnobRadius);
		var xknobMax = that.knob.x+(that.sliderKnobRadius) + (that.canvasWidth/40) + that.gCanvasContext.measureText("Bolling oranje lijn").width;
		
		var yKnobMin = that.knob.y-(that.sliderKnobRadius);
		var yknobMax = that.knob.y+(that.sliderKnobRadius);
		
		//console.log(xKnobMin+" "+xknobMax+" "+yKnobMin+" "+yknobMax);
		
		if( (mouseX > xKnobMin) && (mouseX < xknobMax) && (mouseY > yKnobMin) && (mouseY < yknobMax) ){
			$(that.gCanvas).css({cursor:'pointer'});
		}else{
			$(that.gCanvas).css({cursor:'default'});
		}
		
		//console.log(mouseX,mouseY);
		
		if(that.isMouseDown){
			
			//console.log('MouseMove');
			
			var  gridX =  ( mouseX - that.marginL ) / that.xUnitWidth;
			var  gridY =  ( (that.marginT+that.availHeight) - mouseY ) / that.yUnitWidth;
			
			var gridX = gridX.toFixed(1);
			var gridY = gridY.toFixed(1);
			
			that.X1 = Number( gridX );
			that.Y1 = Number( gridY );
			
			that.diffX = that._diffX = mouseX - that.clickedX;
			that.diffY = that._diffY = mouseY - that.clickedY;
			
			that.isLineMoved = true;
			
			//console.log(that.diffX,that.diffY);
			
			console.log(that.diffX,that.diffY);
			
			//console.log(gridX,gridY);
			
			that.drawCanvas();
			
			//that.isPointOnLine(mouseX,mouseY);
		}
		
		
		if(that.slider.mousedown){
			that.onKnobMove(mouseY);
		}
	}
	
	
	this.onKnobMove = function(curY){
		console.log(that.knob.yMin+" "+that.knob.yMax+" "+curY);
		if( (that.knob.yMin < curY) && (that.knob.yMax > curY) ){
				console.log( that.knob.y  );
				that.knob.y = curY;
				var totalHeight = Math.round(that.knob.yMax-that.knob.yMin);
				var totalUnits = (2.51-0.01);
				var unitValue = totalUnits / totalHeight;
				var curValue = ( (0.01)+( unitValue*(curY-that.knob.yMin) ) ).toFixed(2);
				that.C1 =  -1 * curValue;
				console.log( that.C1 );
		}
			
		that.drawCanvas();	
	}
	
		
	this.onCanvasMouseUp = function(e){
		
		e.preventDefault();
		
		var touch = e.originalEvent && e.originalEvent.touches && e.originalEvent.touches[0];
		e = touch || e;
		
		var mouseX = e.pageX - $(that.gCanvas).offset().left;
		var mouseY = e.pageY - $(that.gCanvas).offset().top;
		
		//that.isBlueLineHighLightRequired = false;	
		that.drawCanvas();
		that.isMouseDown = false;
		
		that.x1 = that.newX1;
		that.y1 = that.newY1; 
		
		that.x2 = that.newX2;
		that.y2 = that.newY2;
		
		that.clickedX =  mouseX;
		that.clickedY =  mouseY;
		
		that.diffX = 0;
		that.diffY = 0;
		
		that.slider.mousedown = false;
		//that.isKnobFocused = false;
	}
	
	this.setCanvasSize = function(){
		if(that.isFullScreenEnabled){
			
			console.log(that.x1 - that.marginL , that.y1 - (that.marginT+that.availHeight) );
			
			var lastX = that.x1 - that.marginL;
			var lastY = that.y1 - (that.marginT+that.availHeight);
			
			that.prevWidth = that.canvasWidth;
			that.prevHeight = that.canvasHeight;
			
			that.canvasWidth = screen.width;
			that.canvasHeight = screen.height;
			
			that.widthRatio = that.canvasWidth / that.prevWidth;
			that.heightRatio = that.canvasHeight / that.prevHeight;
			
			that.diffX = lastX * that.widthRatio;
			that.diffY = lastY * that.heightRatio;
			
			$("#mainContainer").width(that.canvasWidth).height(that.canvasHeight);
			
			that.axisLineWidth = 2.5;
			that.dividerLineWidth = 4;
			that.curveLineWidth = 4.6;
			that.sliderWidth = 6;
			that.sliderKnobRadius = 8;
			that.circleRadius = 7;
			that.legendLineTop = 30;
			that.legendLineThickNess = 3;
			
		}else{
			
			console.log(that.x1 - that.marginL , that.y1 - (that.marginT+that.availHeight) );
			
			var lastX = that.x1 - that.marginL;
			var lastY = that.y1 - (that.marginT+that.availHeight);
			
			that.prevWidth = that.canvasWidth;
			that.prevHeight = that.canvasHeight;
			
			that.canvasWidth = 960;
			that.canvasHeight = 599;

			that.widthRatio = that.canvasWidth / that.prevWidth;
			that.heightRatio = that.canvasHeight / that.prevHeight;
			
			that.axisLineWidth = 1.5;
			that.dividerLineWidth = 3;
			that.curveLineWidth = 2.6;
			that.sliderWidth = 5;
			that.sliderKnobRadius = 6;
			that.circleRadius = 5;
			that.legendLineTop = 20;
			that.legendLineThickNess = 1.5;
			
			that.diffX = lastX * that.widthRatio;
			that.diffY = lastY * that.heightRatio;
			
			$("#mainContainer").width(that.canvasWidth).height(that.canvasHeight);
			
			
		}
		
		//that.canvasWidth = 960;
		//that.canvasHeight = 599;
		
		that.fontSize14 = (14 / 1000) * that.canvasWidth;
		that.fontSize15 = (15 / 1000) * that.canvasWidth;
		that.fontSize16 = (16 / 1000) * that.canvasWidth;
		that.fontSize18 = (18 / 1000) * that.canvasWidth;
		that.fontSize19 = (19 / 1000) * that.canvasWidth;
		that.fontSize20 = (20 / 1000) * that.canvasWidth;
		
		console.log(that.widthRatio,that.heightRatio);
		
		$(that.gCanvas).attr('width',that.canvasWidth).attr('height',that.canvasHeight);
		that.marginL = (15 * that.canvasWidth / 100); /* 10% */
		that.marginR = (30 * that.canvasWidth / 100); /* 30% */
		that.marginT = (10 * that.canvasHeight / 100); /* 10% */
		that.marginB = (12 * that.canvasHeight / 100); /* 10% */
		that.totalWidth = that.gCanvas.width;
		that.totalHeight = that.gCanvas.height;
		that.availWidth = that.totalWidth - that.marginL - that.marginR;
		that.availHeight = that.totalHeight - that.marginT - that.marginB;
		that.totalSegmentsX = 10;
		that.totalSegmentsY = 10;
		that.xUnitWidth = that.availWidth / that.totalSegmentsX;
		that.yUnitWidth = that.availHeight / that.totalSegmentsY;
		//if(!that.isLineMoved){
			that.x1 = that.newX1 = that.marginL + that.diffX;
			that.y1 = that.newY1 = that.marginT+that.availHeight + that.diffY;
			that.x2 = that.newX2 = that.marginL+that.availWidth + that.diffX;
			that.y2 = that.newY2 = that.marginT + that.diffY;
		//}
		
		that.diffX = that.diffY = 0;
		
		/* that.topText = {
			x :  that.marginL+that.availWidth+(that.canvasWidth/18),
			y :  that.marginT
		} */
		
		that.slider.x = that.marginL+that.availWidth+(that.canvasWidth/18);
		that.slider.y = that.marginT;
		that.slider.width = 5;
		that.slider.height = (that.canvasHeight/3);
		
		that.gCanvasContext.font = that.fontSize16+"px Arial";
		var topTextWidth = that.gCanvasContext.measureText("Gelijke verdeling").width;
		var topTextHeight = parseInt(that.gCanvasContext.font.match(/\d+/), 10);
		
		var bufferX =  topTextWidth / 6;
		
		that.knob.x = that.slider.x+bufferX;
		that.knob.y = that.slider.y+topTextHeight+17;
		
		that.knob.yMin = that.slider.y+topTextHeight+17;
		that.knob.yMax = that.slider.y+topTextHeight+17+that.slider.height;
		that.knob.y = that.knob.yMin + ( Math.abs(that.C1) / ( (2.5-0.01) / (that.knob.yMax - that.knob.yMin)  ) );
		
		that.drawCanvas();
		
		var yNumTextWidth = that.gCanvasContext.measureText( ((10)*10) ).width;
		
		$("#resetBtn").css({'font-size':Math.ceil(that.fontSize18)+"px"});
		
		var resetBtnHeight = Math.round( $("#resetBtn").height() );
		
		$("#resetBtn").css({bottom:(that.marginB-(resetBtnHeight+(resetBtnHeight/2)) )+"px",left:yNumTextWidth+"px"});
	}
	
	this.drawCanvas = function(){
		that.gCanvas.width =  that.gCanvas.width;
		
		// Fill Grid Width Blue Color;
		/* that.gCanvasContext.beginPath();
		that.gCanvasContext.fillStyle = "#E9F6FE";
		that.gCanvasContext.rect(that.marginL,that.marginT,that.availWidth,that.availHeight);
		that.gCanvasContext.fill(); */
		
		console.log(that.fontSize20);
		
		// Draw "0" Text
		that.gCanvasContext.fillStyle = "#000";
		that.gCanvasContext.font = "italic "+that.fontSize18+"px Arial";
		var zeroTextWidth = that.gCanvasContext.measureText( "O" ).width;
		var zeroTextHeight = parseInt(that.gCanvasContext.font.match(/\d+/), 10);
		that.gCanvasContext.fillText( "O" , that.marginL-4-zeroTextWidth , that.marginT+that.availHeight+4+zeroTextHeight );
		
		var legendXPos = (that.canvasWidth/18);
		
		// Draw Blue Legends 
		that.gCanvasContext.fillStyle = "#000";
		that.gCanvasContext.font = that.fontSize16+"px Arial";
		var blueLegendTextWidth = that.gCanvasContext.measureText( "Gelijke verdeling" ).width;
		that.gCanvasContext.fillText( "Gelijke verdeling" , that.marginL+that.availWidth+legendXPos , that.marginT+that.availHeight-(that.canvasHeight/5.4)  );
		
		that.gCanvasContext.beginPath();
		that.gCanvasContext.strokeStyle = "#ef3f6b";
		that.gCanvasContext.lineWidth = that.legendLineThickNess;
		that.gCanvasContext.moveTo(that.marginL+that.availWidth+legendXPos+(blueLegendTextWidth/3.7) , that.marginT+that.availHeight-(that.canvasHeight/5.4)+that.legendLineTop);
		that.gCanvasContext.lineTo(that.marginL+that.availWidth+legendXPos+(blueLegendTextWidth/3.7)+(blueLegendTextWidth/2.5),that.marginT+that.availHeight-(that.canvasHeight/5.4)+that.legendLineTop);
		that.gCanvasContext.stroke();
		
		that.blueLegendCircleObj.x = that.marginL+that.availWidth+legendXPos+(blueLegendTextWidth/3.7)+(blueLegendTextWidth/2.5)/2;
		that.blueLegendCircleObj.y = that.marginT+that.availHeight-(that.canvasHeight/5.4)+that.legendLineTop;
		
		if(that.blueLegendCircleObj.isHighLightRequired){
			that.gCanvasContext.save();
			that.gCanvasContext.globalAlpha = 0.25;
			that.gCanvasContext.beginPath();
			that.gCanvasContext.fillStyle = '#ef3f6b';
			that.gCanvasContext.arc(that.marginL+that.availWidth+legendXPos+(blueLegendTextWidth/3.7)+(blueLegendTextWidth/2.5)/2,that.marginT+that.availHeight-(that.canvasHeight/5.4)+that.legendLineTop,(3*that.circleRadius)-1,0,2*Math.PI,false);
			that.gCanvasContext.fill();	
			that.gCanvasContext.restore();
		}
		
		that.gCanvasContext.beginPath();
		//that.gCanvasContext.strokeStyle = '#000';
		that.gCanvasContext.fillStyle = '#ef3f6b';
		that.gCanvasContext.arc(that.marginL+that.availWidth+legendXPos+(blueLegendTextWidth/3.7)+(blueLegendTextWidth/2.5)/2,that.marginT+that.availHeight-(that.canvasHeight/5.4)+that.legendLineTop,that.circleRadius,0,2*Math.PI,false);
		//that.gCanvasContext.stroke();
		that.gCanvasContext.fill();
		
		
		
		// End
		
		// Draw Orange Legends 
		that.gCanvasContext.fillStyle = "#000";
		that.gCanvasContext.font = that.fontSize16+"px Arial";
		var orangeLegendTextWidth = that.gCanvasContext.measureText( "Gelijke verdeling" ).width;
		that.gCanvasContext.fillText( "Niet gelijke verdeling" , that.marginL+that.availWidth+legendXPos , that.marginT+that.availHeight-(that.canvasHeight/20)  );
		
		that.gCanvasContext.beginPath();
		that.gCanvasContext.strokeStyle = "#70bf54";
		that.gCanvasContext.lineWidth = that.legendLineThickNess;
		that.gCanvasContext.moveTo(that.marginL+that.availWidth+legendXPos+(orangeLegendTextWidth/3.7) , that.marginT+that.availHeight-(that.canvasHeight/20)+that.legendLineTop);
		that.gCanvasContext.lineTo(that.marginL+that.availWidth+legendXPos+(orangeLegendTextWidth/3.7)+(orangeLegendTextWidth/2.5),that.marginT+that.availHeight-(that.canvasHeight/20)+that.legendLineTop);
		that.gCanvasContext.stroke();
		
		that.orangeLegendCircleObj.x = that.marginL+that.availWidth+legendXPos+(orangeLegendTextWidth/3.7)+(orangeLegendTextWidth/2.5)/2;
		that.orangeLegendCircleObj.y = that.marginT+that.availHeight-(that.canvasHeight/20)+that.legendLineTop;
		
		if(that.orangeLegendCircleObj.isHighLightRequired){
			that.gCanvasContext.save();
			that.gCanvasContext.globalAlpha = 0.25;
			that.gCanvasContext.beginPath();
			that.gCanvasContext.fillStyle = '#70bf54';
			that.gCanvasContext.arc(that.marginL+that.availWidth+legendXPos+(orangeLegendTextWidth/3.7)+(orangeLegendTextWidth/2.5)/2,that.marginT+that.availHeight-(that.canvasHeight/20)+that.legendLineTop,(3*that.circleRadius)-1,0,2*Math.PI,false);
			that.gCanvasContext.fill();	
			that.gCanvasContext.restore();
		}
		
		that.gCanvasContext.beginPath();
		//that.gCanvasContext.strokeStyle = '#000';
		that.gCanvasContext.fillStyle = '#70bf54';
		that.gCanvasContext.arc(that.marginL+that.availWidth+legendXPos+(orangeLegendTextWidth/3.7)+(orangeLegendTextWidth/2.5)/2,that.marginT+that.availHeight-(that.canvasHeight/20)+that.legendLineTop,that.circleRadius,0,2*Math.PI,false);
		//that.gCanvasContext.stroke();
		that.gCanvasContext.fill();
		
		// End
		
		$(".topText,.bottomText,#slider_val_label").css({'font-size':that.fontSize15+"px"});
		
		var textHeight = $(".topText").height();

		$("#sliderComponent").css({height:(that.canvasHeight/3)+(textHeight*2)+33+"px"});
		$("#valSlider").css({top:textHeight+17+"px",height:(that.canvasHeight/3)+"px"});
		$("#sliderComponent").css({top:that.marginT+"px",left:that.marginL+that.availWidth+legendXPos+"px"});
		
		var curBottom = parseInt( $("#valSlider").find('span').css('bottom') );
		var curHeight = $("#slider_val_label").height() / 2;
		var sliderHeight = $("#valSlider span").height() / 2;
		$("#slider_val_label").css({border:"0px solid red",top:-curHeight+sliderHeight+"px"});
		
		var curBottom =  $("#valSlider span").css('bottom').replace("px","") - ( $("#valSlider .slider_knob_bg").height() - $("#valSlider span").height() )/2;
		$("#valSlider .slider_knob_bg").css({bottom:curBottom+"px"});
		
		
		// Draw Slider Top Text 
		that.gCanvasContext.fillStyle = "#000";
		that.gCanvasContext.font = that.fontSize16+"px Arial";
		var topTextWidth = that.gCanvasContext.measureText("Gelijke verdeling").width;
		var topTextHeight = parseInt(that.gCanvasContext.font.match(/\d+/), 10);
		that.gCanvasContext.fillText( "Gelijke verdeling" , that.slider.x , that.slider.y+(topTextHeight/2)  );
		
		
		// Draw Slider Bottom Text 
		that.gCanvasContext.fillStyle = "#000";
		that.gCanvasContext.font = that.fontSize16+"px Arial";
		var topTextHeight = parseInt(that.gCanvasContext.font.match(/\d+/), 10);
		that.gCanvasContext.fillText( "Niet gelijke verdeling" , that.slider.x , that.slider.y+topTextHeight+that.slider.height+17+(2*topTextHeight) );

		
		var xPos = that.marginL;
		var yPos = that.marginT+that.availHeight;
		xNumTextHeight = 0;
		var xNumTextWidth = 0;
		
		for(var i=0;i<that.totalSegmentsX+1;i++){
			
			/* that.gCanvasContext.beginPath();
			that.gCanvasContext.lineWidth = that.axisLineWidth;
			that.gCanvasContext.strokeStyle = "#000";
			that.gCanvasContext.moveTo(xPos,yPos+2);
			that.gCanvasContext.lineTo(xPos,yPos+6);
			that.gCanvasContext.stroke(); */
			
			if(i != 0){
				// White Grid Lines 
				that.gCanvasContext.beginPath();
				that.gCanvasContext.lineWidth = that.axisLineWidth;
				that.gCanvasContext.strokeStyle = "#00aeef";
				that.gCanvasContext.moveTo(Math.round(xPos),Math.round(yPos) );
				that.gCanvasContext.lineTo(Math.round(xPos),Math.round(yPos-that.availHeight) );
				that.gCanvasContext.stroke();
			
				that.gCanvasContext.fillStyle = "#000";
				that.gCanvasContext.font = that.fontSize16+"px Arial";
				
				xNumTextWidth = that.gCanvasContext.measureText( ((i)*10) ).width;
				xNumTextHeight = parseInt(that.gCanvasContext.font.match(/\d+/), 10);
				
				//console.log( parseInt(that.gCanvasContext.font.match(/\d+/), 10) );
				
				that.gCanvasContext.fillText( ((i)*10) , xPos-(xNumTextWidth/2) , yPos+8+xNumTextHeight  );
			}
			
			console.log(Math.round(xPos));
			
			xPos = xPos + that.xUnitWidth;
		}
		
		var xPos = that.marginL;
		var yPos = that.marginT+that.availHeight;
		var yNumTextHeight = 0;
		var yNumTextWidth = 0;
		
		for(var i=0;i<that.totalSegmentsY+1;i++){
			
			
			/* that.gCanvasContext.beginPath();
			that.gCanvasContext.lineWidth = that.axisLineWidth;
			that.gCanvasContext.strokeStyle = "#000";
			that.gCanvasContext.moveTo(xPos-2,yPos);
			that.gCanvasContext.lineTo(xPos-6,yPos);
			that.gCanvasContext.stroke(); */
			
			if(i != 0){
				// White Grid Lines 
				that.gCanvasContext.beginPath();
				that.gCanvasContext.lineWidth = that.axisLineWidth;
				that.gCanvasContext.strokeStyle = "#00aeef";
				that.gCanvasContext.moveTo(Math.round(xPos),Math.round(yPos));
				that.gCanvasContext.lineTo(Math.round(xPos+that.availWidth),Math.round(yPos));
				that.gCanvasContext.stroke();
			
				
				that.gCanvasContext.fillStyle = "#000";
				that.gCanvasContext.font = that.fontSize16+"px Arial"
				
				yNumTextWidth = that.gCanvasContext.measureText( ((i)*10) ).width;
				yNumTextHeight = parseInt(that.gCanvasContext.font.match(/\d+/), 10);
				
				that.gCanvasContext.fillText( ((i)*10) , xPos-8-3-yNumTextWidth , yPos+(yNumTextHeight/2)-3 );
			}

			yPos = yPos - that.yUnitWidth;
		}
		
		// Slider
		
		var bufferX =  topTextWidth / 6;
		
		that.gCanvasContext.beginPath();
		that.gCanvasContext.lineJoin = "round";
		that.gCanvasContext.lineWidth = that.sliderWidth;
		that.gCanvasContext.strokeStyle = "#9B9B9B";
		that.gCanvasContext.moveTo(that.slider.x+bufferX,that.slider.y+topTextHeight+17);
		that.gCanvasContext.lineTo(that.slider.x+that.slider.width-that.sliderWidth+bufferX,that.slider.y+topTextHeight+17);
		that.gCanvasContext.lineTo(that.slider.x+that.slider.width-that.sliderWidth+bufferX,that.slider.y+topTextHeight+17+that.slider.height);
		that.gCanvasContext.lineTo(that.slider.x+bufferX,that.slider.y+topTextHeight+17+that.slider.height);
		that.gCanvasContext.lineTo(that.slider.x+bufferX,that.slider.y+topTextHeight+17);
		that.gCanvasContext.closePath();
		that.gCanvasContext.stroke();
		
		if(that.slider.mousedown || that.isKnobFocused){
			var backDropRadius = that.sliderKnobRadius + 6;		
		}else{
			var backDropRadius = that.sliderKnobRadius + 3;	
		}
		
		that.gCanvasContext.save();
		that.gCanvasContext.globalAlpha = 0.4;
		that.gCanvasContext.beginPath();
		that.gCanvasContext.fillStyle = "#000";
		that.gCanvasContext.arc(that.knob.x,that.knob.y,backDropRadius,0,2*Math.PI,true);
		that.gCanvasContext.fill();
		that.gCanvasContext.restore();
		
		that.gCanvasContext.beginPath();
		that.gCanvasContext.fillStyle = "#000";
		that.gCanvasContext.arc(that.knob.x,that.knob.y,that.sliderKnobRadius,0,2*Math.PI,true);
		that.gCanvasContext.fill();
		
		that.gCanvasContext.beginPath();
		that.gCanvasContext.font = ""+that.fontSize16+"px Arial";
		var topTextHeight = parseInt(that.gCanvasContext.font.match(/\d+/), 10);
		that.gCanvasContext.fillText( "Bolling oranje lijn" , that.knob.x+(that.canvasWidth/40) , that.knob.y+(topTextHeight/2)-(that.sliderKnobRadius/2)  );
		
		that.drawCurveAndLine();
		
		// y-axis
		that.gCanvasContext.beginPath();
		that.gCanvasContext.lineWidth = that.axisLineWidth;
		that.gCanvasContext.strokeStyle = "#000";
		that.gCanvasContext.moveTo(that.marginL ,that.marginT-(that.axisLineWidth/2));
		that.gCanvasContext.lineTo(that.marginL ,that.marginT+that.availHeight-(that.axisLineWidth/2));
		that.gCanvasContext.stroke();
		
		/* that.gCanvasContext.save();
		that.gCanvasContext.fillStyle = "#000";
		that.gCanvasContext.font = ""+that.fontSize18+"px Arial";
		var textHeight = parseInt(that.gCanvasContext.font.match(/\d+/), 10);
		var yAxisTextWidth = yNumTextWidth;
		var yAxisTextHeight = that.gCanvasContext.measureText("Percentage van het totale inkomen").width;
		that.gCanvasContext.translate(Math.round(that.marginL-6-yNumTextWidth-textHeight),Math.round(that.marginT+yAxisTextHeight) );
		that.gCanvasContext.rotate(-89.96*Math.PI/180);
		that.gCanvasContext.fillText( "Percentage van het totale inkomen" , 0 , 0  );
		that.gCanvasContext.restore(); */
		
		that.gCanvasContext.fillStyle = "#000";
		that.gCanvasContext.font = ""+that.fontSize18+"px Arial";
		var textHeight = parseInt(that.gCanvasContext.font.match(/\d+/), 10);
		that.gCanvasContext.fillText( "Percentage van het totale inkomen" , that.marginL , that.marginT-textHeight  );
		
		//console.log( (that.marginB+" "+(2*resetBtnHeight) ) )
	}
	
	
	this.drawCurveAndLine = function(){
		/** 
			Draw Curve 
		*/
		
		var curvePoints = [];
		
		for(var x=0;x<=1.01;x+=0.01){
			y = Math.pow(x,Math.pow(10,-(that.C1)) );
			curvePoints.push( {x: (x*that.totalSegmentsX).toFixed(2) , y:(y*that.totalSegmentsX).toFixed(2) } );
			//console.log(x,y);
		}
		
		//console.log(curvePoints);
		
		var xPos = that.marginL;
		var yPos = that.marginT+that.availHeight;
		
		that.lineDots = [];
		
		for(var i=0;i<curvePoints.length;i++){
			var curX = that.marginL+(curvePoints[i].x*that.xUnitWidth);
			var curY = that.marginT+that.availHeight-(curvePoints[i].y*that.yUnitWidth);
			
			if(i%10 == 0){
				
				that.lineDots.push({x: xPos , y:yPos});
				
				if(that.isBlueCircleHighLightRequired){
					that.gCanvasContext.save();
					that.gCanvasContext.beginPath();
					that.gCanvasContext.globalAlpha = 0.25;
					that.gCanvasContext.fillStyle = '#ef3f6b';
					that.gCanvasContext.arc(xPos,yPos,(2*that.circleRadius)+1,0,2*Math.PI,false);
					that.gCanvasContext.fill();				
					that.gCanvasContext.restore();
				}
				
				that.gCanvasContext.beginPath();
				that.gCanvasContext.lineWidth = that.curveLineWidth;
				//that.gCanvasContext.strokeStyle = '#000';
				that.gCanvasContext.fillStyle = '#ef3f6b';
				that.gCanvasContext.arc(xPos,yPos,that.circleRadius,0,2*Math.PI,false);
				//that.gCanvasContext.stroke();
				that.gCanvasContext.fill();
				
				xPos = xPos + that.xUnitWidth;	
				yPos = yPos - that.yUnitWidth;
			}
		
			//console.log(i);
		}
		
		// Orange Line
		that.gCanvasContext.beginPath();
		that.gCanvasContext.lineWidth = that.curveLineWidth;
		that.gCanvasContext.strokeStyle = '#70bf54';
		that.gCanvasContext.moveTo(that.marginL,that.marginT + that.availHeight);
		that.gCanvasContext.lineTo(that.marginL+that.availWidth,that.marginT);
		that.gCanvasContext.stroke();
		
		for(var i=0;i<curvePoints.length;i++){
			var curX = that.marginL+(curvePoints[i].x*that.xUnitWidth);
			var curY = that.marginT+that.availHeight-(curvePoints[i].y*that.yUnitWidth);
			if(i==0){
				that.gCanvasContext.beginPath();
				that.gCanvasContext.lineWidth = that.curveLineWidth;
				that.gCanvasContext.strokeStyle = '#70bf54';
				that.gCanvasContext.moveTo(curX,curY );
			}else{
				that.gCanvasContext.lineTo(curX,curY);				
			}
		}
		
		that.gCanvasContext.stroke();
		
		var xPos = that.marginL;
		var yPos = that.marginT + that.availHeight;
		
		// Draw Line
		
		that.newX1 = (that.x1+(that.diffX) );
		that.newY1 = (that.y1+(that.diffY) );
		
		that.newX2 = (that.x2+(that.diffX) );
		that.newY2 = (that.y2+(that.diffY) );
		
		//that.diffX = that.diffY = 0;
		
		//console.log( that.newX1 , that.newY1 );
		
		that.gCanvasContext.beginPath();
		that.gCanvasContext.lineWidth = that.curveLineWidth;
		that.gCanvasContext.strokeStyle = '#ef3f6b';
		that.gCanvasContext.moveTo(that.newX1,that.newY1);
		that.gCanvasContext.lineTo(that.newX2,that.newY2);
		that.gCanvasContext.stroke();
		
		if(that.isBlueLineHighLightRequired){
			that.gCanvasContext.save();
			that.gCanvasContext.beginPath();
			that.gCanvasContext.globalAlpha = 0.25;
			that.gCanvasContext.lineWidth = 3*that.curveLineWidth;
			that.gCanvasContext.strokeStyle = '#ef3f6b';
			that.gCanvasContext.moveTo(that.newX1,that.newY1);
			that.gCanvasContext.lineTo(that.newX2,that.newY2);
			that.gCanvasContext.stroke();
			that.gCanvasContext.restore();
		}
		
		
		// x-axis
		that.gCanvasContext.beginPath();
		that.gCanvasContext.lineWidth = that.axisLineWidth;
		that.gCanvasContext.strokeStyle = "#000";
		that.gCanvasContext.moveTo(that.marginL-(that.axisLineWidth/2),that.marginT+that.availHeight);
		that.gCanvasContext.lineTo(that.marginL+that.availWidth+(that.axisLineWidth/2),that.marginT+that.availHeight);
		that.gCanvasContext.stroke();

		that.gCanvasContext.fillStyle = "#000";
		that.gCanvasContext.font = ""+that.fontSize18+"px Arial";
		var xAxisTextWidth = that.gCanvasContext.measureText("Percentage personen van het totaal").width;
		var textHeight = parseInt(that.gCanvasContext.font.match(/\d+/), 10);
		that.gCanvasContext.fillText( "Percentage personen van het totaal" , that.marginL+that.availWidth-xAxisTextWidth , that.marginT+that.availHeight+6+xNumTextHeight+textHeight+20  );
		
		/** 
			Draw Curve Dots 
		*/
		var xPos = that.marginL;
		var yPos = that.marginT+that.availHeight;
		
		
		that.circleDots = [];
		
		for(var i=0;i<curvePoints.length;i++){
			var curX = that.marginL+(curvePoints[i].x*that.xUnitWidth);
			var curY = that.marginT+that.availHeight-(curvePoints[i].y*that.yUnitWidth);
			
			if(i == 20 || i == 40 || i == 60 || i == 80){
				
				that.circleDots.push({x: curX , y:curY ,index:i});
				
				if(that.isYellowCircleHighLightRequired){
					if(that.yellowCircleIndex == i){
						console.log(i);
						
						that.gCanvasContext.save();
						that.gCanvasContext.beginPath();
						that.gCanvasContext.globalAlpha = 0.3;
						that.gCanvasContext.fillStyle = '#70bf54';
						that.gCanvasContext.arc(curX,curY,(2*that.circleRadius)+1,0,2*Math.PI,false);
						that.gCanvasContext.fill();				
						that.gCanvasContext.restore();					
					}
				}
				
				that.gCanvasContext.beginPath();
				that.gCanvasContext.lineWidth = 2*that.axisLineWidth;
				//that.gCanvasContext.strokeStyle = '#000';
				that.gCanvasContext.fillStyle = '#70bf54';
				that.gCanvasContext.arc(curX,curY,that.circleRadius,0,2*Math.PI,false);
				//that.gCanvasContext.stroke();
				that.gCanvasContext.fill();
			}
			
			//console.log(i);
		}
		
		//console.log(that.lineDots);
		
	
	}
	
	
	this.openFullscreen = function() {
	  
	  if(!that.isFullScreenEnabled){
			  var elem = document.getElementById("mainContainer");
			  if (elem.requestFullscreen) {
				elem.requestFullscreen();
			  } else if (elem.mozRequestFullScreen) { /* Firefox */
				elem.mozRequestFullScreen();
			  } else if (elem.webkitRequestFullscreen) { /* Chrome, Safari & Opera */
				elem.webkitRequestFullscreen();
			  } else if (elem.msRequestFullscreen) { /* IE/Edge */
				console.log("msRequestFullscreen");
				elem.msRequestFullscreen();
			  }
			  
			  $("#fullScreenImage").hide();
			  $("#exitScreenImage").show();
			  
			  that.isFullScreenEnabled  = true;
			  
			 /* setTimeout(function(){
				  that.setCanvasSize();
			  },300); */
	  }else{
			var elem = document;
		
			if (elem.exitFullscreen) {
				elem.exitFullscreen();
			} else if (elem.mozCancelFullScreen) { /* Firefox */
				elem.mozCancelFullScreen();
			} else if (elem.webkitExitFullscreen) { /* Chrome, Safari and Opera */
				elem.webkitExitFullscreen();
			} else if (elem.msExitFullscreen) { /* IE/Edge */
				elem.msExitFullscreen();
			}	
			
			$("#fullScreenImage").show();
			$("#exitScreenImage").hide();
			
			that.isFullScreenEnabled = false;
			
			/* setTimeout(function(){
			  that.setCanvasSize();
			},300) */;	  
	  }
		  
	}
	
	
	
}