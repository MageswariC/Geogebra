var Graph = function(){
	
	var that = this;
	
	that.isIPAD = (/iPad|iPhone/i.test(navigator.userAgent));
	that.isAndroid = navigator.userAgent.toLowerCase().indexOf("android") > -1; 
	that.canvasWidth = 960;
	that.canvasHeight = 599;	
	that.C1 = -0.37;
	that.isMouseDown = false;
	that.isBlueLineHighLightRequired = false; 
	that.isBlueCircleHighLightRequired = false; 
	that.isYellowCircleHighLightRequired = false;
	that.yellowCircleIndex = null;
	that.isFullScreenEnabled = false;
	that.Y1 = that._Y1 = 0;
	that.X1 = that._X1 = 0;
	that.diffX = that._diffX = 0;
	that.diffY = that._diffY = 0;
	that.x1 = 0;
	that.y1 = 0;
	that.marginL = 0;
	that.marginR = 0;
	that.marginT = 0;
	that.marginB = 0;
	that.totalWidth = 0;
	that.totalHeight = 0;
	that.availWidth = that.totalWidth - that.marginL - that.marginR;
	that.availHeight = that.totalHeight - that.marginT - that.marginB;
	that.isLineMoved = false;
	that.blueLegendCircleObj = {};
	that.orangeLegendCircleObj = {};
	that.slider = {mousedown:false};
	that.knob = {};
	
	that.a = 1.8;
	that.dragCircle = {x:0,y:0,radius:0};
	
	var interSectionPoint = {x:0,y:0};
	var interSectionPoint2 = {x:0,y:0};
	var interSectionPoint3 = {x:0,y:0};
	
	that.legendBox = {};
	that.legendBox.diffX = 0;
	that.legendBox.diffY = 0;
	that.legendBox.width = 300;
	that.legendBox.height = 150;
	that.legendBox.x = that.canvasWidth - that.legendBox.width - ( that.canvasWidth / 40 );
	that.legendBox.y = that.canvasHeight / 60;
	that.legendBox.mouseDown = false;
	
	this.init = function(){
		that.gCanvas = document.getElementById("graphCanvas");
		that.gCanvasContext = that.gCanvas.getContext('2d');
		
		//alert(that.isAndroid);
		
		if(that.isIPAD || that.isAndroid){
			$(that.gCanvas).off('touchstart').on('touchstart',that.onCanvasMouseDown);
			$(that.gCanvas).off('touchend').on('touchend',that.onCanvasMouseUp);
			$(that.gCanvas).off('touchmove').on('touchmove',that.onCanvasMouseMove);
			$("#fullScreenBtn").hide();
		}else{
			$(that.gCanvas).off('mousedown').on('mousedown',that.onCanvasMouseDown);
			$(document).off('mouseup').on('mouseup',that.onCanvasMouseUp);
			$(that.gCanvas).off('mousemove').on('mousemove',that.onCanvasMouseMove);
			$("#fullScreenBtn").show();
		}
		
		$("#resetBtn").off('click').on('click',that.onResetBtnClick);
		$("#fullScreenBtn").off('click').on('click',that.openFullscreen);
		
		$("#fullScreenBtn").off('mouseover').on('mouseover',that.onBtnMouseOver);
		$("#fullScreenBtn").off('mouseout').on('mouseout',that.onBtnMouseOut);
				
		document.addEventListener("fullscreenchange",that.onActivityFullScreen);
		document.addEventListener("mozfullscreenchange",that.onActivityFullScreen);
		document.addEventListener("webkitfullscreenchange",that.onActivityFullScreen);
		document.addEventListener("MSFullscreenChange",that.onActivityFullScreen);
		
		$("#canvasSliderKnob").off('focus').on('focus',that.onKnobFocus);
		$("#canvasSliderKnob").off('blur').on('blur',that.onKnobBlur);
		
		$(document).off('keydown').on('keydown',that.onDocumentKeyDown);
		
		$("#exitScreenImage").hide();

		//that.initSlider();
		that.setCanvasSize();
		
	}
	
	this.onDocumentKeyDown = function(e){
		console.log(e.keyCode+" "+that.isKnobFocused);
		
		if(that.isKnobFocused){
			if(e.keyCode == 38){
				that.onKnobMove(that.knob.y-1);
			}else if(e.keyCode == 40){
				that.onKnobMove(that.knob.y+1);
			}
		}
	}
	
	this.onKnobFocus = function(){
		that.isKnobFocused = true;
		that.drawCanvas();
	}
	
	this.onKnobBlur = function(){
		that.isKnobFocused = false;	
		that.drawCanvas();
	}
	
	this.onBtnMouseOver = function(){
		$("#fullScreenBtn").css({backgroundColor:"#eee"});	
		$("#fullScreenBtn img").css({opacity:1});	
	}
	
	this.onBtnMouseOut = function(){
		$("#fullScreenBtn").css({background:"#fff"});	
		$("#fullScreenBtn img").css({opacity:0.5});			
	}
	
	
	this.onActivityFullScreen = function(){
		if ( document.fullscreenElement || document.webkitFullscreenElement || document.mozFullScreenElement || document.msFullscreenElement ) {
			 $("#fullScreenImage").hide();
			  $("#exitScreenImage").show();
				
			that.isFullScreenEnabled  = true;	
			that.setCanvasSize();
			
		}else{
			$("#fullScreenImage").show();
			$("#exitScreenImage").hide();

			that.isFullScreenEnabled  = false;	
			that.setCanvasSize();
			
		}
	}
	
	this.onResetBtnClick = function(){
		that.isMouseDown = false;
		that.isBlueLineHighLightRequired = false; 
		that.isBlueCircleHighLightRequired = false; 
		that.isYellowCircleHighLightRequired = false;
		that.yellowCircleIndex = null;
		that.a = 1.8;
		that.drawCanvas();
	}
	
	this.onCanvasMouseDown = function(e){
		
		e.preventDefault();
		
		var touch = e.originalEvent && e.originalEvent.touches && e.originalEvent.touches[0];
		e = touch || e;
		
		var mouseX = e.pageX - $(that.gCanvas).offset().left;
		var mouseY = e.pageY - $(that.gCanvas).offset().top;
		
		//that.diffX = 0;
		//that.diffY = 0;
		
		//console.log(mouseX,mouseY);
		
		var convertedX = (mouseX - that.marginL)/ that.xUnitWidth;
		convertedX = Number( convertedX.toFixed(2) );
		
		var convertedY = ( (that.marginT + that.availHeight) - mouseY)/ that.yUnitWidth;
		convertedY = Number( convertedY.toFixed(2) );
		
		console.log(convertedX,convertedY);
		
		var xMin = that.dragCircle.x - that.dragCircle.radius;
		var xMax = that.dragCircle.x + that.dragCircle.radius;
		
		var yMin = that.dragCircle.y - that.dragCircle.radius;
		var yMax = that.dragCircle.y + that.dragCircle.radius;
		
		if( (xMin < mouseX) && (xMax > mouseX) && (yMin < mouseY) && (mouseY < yMax) ){
			that.isMouseDown = true;
			console.log('MOUSE DOWN');
		}
		
		var xMin = that.legendBox.x;
		var xMax = that.legendBox.x + that.legendBox.width;
		
		
		var yMin = that.legendBox.y;
		var yMax = that.legendBox.y + that.legendBox.height;
		
		if( (xMin < mouseX) && (xMax > mouseX) && (yMin < mouseY) && (mouseY < yMax) ){
			that.legendBox.mouseDown = true;
			
			that.legendBox.diffX = mouseX - that.legendBox.x;
			that.legendBox.diffY = mouseY - that.legendBox.y;
			
			//console.log('LEGEND MOUSE DOWN');
		}
		
		that.drawCanvas();
	}

	this.onCanvasMouseMove = function(e){
		
		e.preventDefault();
		
		var touch = e.originalEvent && e.originalEvent.touches && e.originalEvent.touches[0];
		e = touch || e;
		
		var mouseX = e.pageX - $(that.gCanvas).offset().left;
		var mouseY = e.pageY - $(that.gCanvas).offset().top;
		
		var convertedX = (mouseX - that.marginL)/ that.xUnitWidth;
		convertedX = Number( convertedX.toFixed(2) );
		
		var convertedY = ( (that.marginT + that.availHeight) - mouseY)/ that.yUnitWidth;
		convertedY = Number( convertedY.toFixed(2) );
		
		//console.log(that.isMouseDown);
		
		if(that.isMouseDown){
			//console.log(that.isMouseDown);
			if( (convertedY >= 1) && (convertedY <= 4)){
				that.a = convertedY;
			}
			//console.log(that.a);
		}
		
		if(that.legendBox.mouseDown){
						
			//console.log(that.legendBox.diffX+" "+that.legendBox.diffY);
			
			that.legendBox.x = mouseX - that.legendBox.diffX;
			that.legendBox.y = mouseY - that.legendBox.diffY;
			
			//console.log(that.legendBox.x+" "+that.legendBox.y);
		}
		
		that.drawCanvas();
	}
		
		
	this.onCanvasMouseUp = function(e){
		
		e.preventDefault();
		
		var touch = e.originalEvent && e.originalEvent.touches && e.originalEvent.touches[0];
		e = touch || e;
		
		var mouseX = e.pageX - $(that.gCanvas).offset().left;
		var mouseY = e.pageY - $(that.gCanvas).offset().top;
		
		var convertedX = (mouseX - that.marginL)/ that.xUnitWidth;
		convertedX = Number( convertedX.toFixed(2) );
		
		var convertedY = ( (that.marginT + that.availHeight) - mouseY)/ that.yUnitWidth;
		convertedY = Number( convertedY.toFixed(2) );
		
		//console.log(that.isMouseDown);
		
		if(that.isMouseDown){
			//console.log(that.isMouseDown);
			if( (convertedY >= 1) && (convertedY <= 4)){
				that.a = convertedY;
			}
			//console.log(that.a);
		}
		
		//that.isBlueLineHighLightRequired = false;	
		that.drawCanvas();
		that.isMouseDown = false;
		
		that.x1 = that.newX1;
		that.y1 = that.newY1; 
		
		that.x2 = that.newX2;
		that.y2 = that.newY2;
		
		that.clickedX =  mouseX;
		that.clickedY =  mouseY;
		
		that.diffX = 0;
		that.diffY = 0;
		
		that.legendBox.mouseDown = false;
		
		that.slider.mousedown = false;
		//that.isKnobFocused = false;
	}
	
	this.setCanvasSize = function(){
		if(that.isFullScreenEnabled){
			
			console.log(that.x1 - that.marginL , that.y1 - (that.marginT+that.availHeight) );
			
			var lastX = that.x1 - that.marginL;
			var lastY = that.y1 - (that.marginT+that.availHeight);
			
			that.prevWidth = that.canvasWidth;
			that.prevHeight = that.canvasHeight;
			
			that.canvasWidth = screen.width;
			that.canvasHeight = screen.height;
			
			that.widthRatio = that.canvasWidth / that.prevWidth;
			that.heightRatio = that.canvasHeight / that.prevHeight;
			
			that.diffX = lastX * that.widthRatio;
			that.diffY = lastY * that.heightRatio;
			
			$("#mainContainer").width(that.canvasWidth).height(that.canvasHeight);
			
			that.axisLineWidth = 2.5;
			that.dividerLineWidth = 4;
			that.curveLineWidth = 4.6;
			that.sliderWidth = 6;
			that.sliderKnobRadius = 8;
			that.dragCircle.radius = 7;
			that.legendLineTop = 30;
			that.legendLineThickNess = 3;
			
			that.legendBox.width = 600;
			that.legendBox.height = 240;
			
			that.legendBox.x = that.legendBox.x * that.widthRatio;
			that.legendBox.y = that.legendBox.y * that.heightRatio;
			
		}else{
			
			//console.log(that.x1 - that.marginL , that.y1 - (that.marginT+that.availHeight) );
			
			var lastX = that.x1 - that.marginL;
			var lastY = that.y1 - (that.marginT+that.availHeight);
			
			that.prevWidth = that.canvasWidth;
			that.prevHeight = that.canvasHeight;
			
			that.canvasWidth = 960;
			that.canvasHeight = 599;

			that.widthRatio = that.canvasWidth / that.prevWidth;
			that.heightRatio = that.canvasHeight / that.prevHeight;
			
			that.axisLineWidth = 1.5;
			that.dividerLineWidth = 3;
			that.curveLineWidth = 2.6;
			that.sliderWidth = 5;
			that.sliderKnobRadius = 6;
			that.dragCircle.radius = 5;
			that.legendLineTop = 20;
			that.legendLineThickNess = 1.5;
			
			that.diffX = lastX * that.widthRatio;
			that.diffY = lastY * that.heightRatio;
			
			$("#mainContainer").width(that.canvasWidth).height(that.canvasHeight);
			
			that.legendBox.width = 300;
			that.legendBox.height = 140;
			
			that.legendBox.x = that.legendBox.x * that.widthRatio;
			that.legendBox.y = that.legendBox.y * that.heightRatio;
		}
		
		//that.canvasWidth = 960;
		//that.canvasHeight = 599;
		
		that.fontSize14 = (14 / 1000) * that.canvasWidth;
		that.fontSize15 = (15 / 1000) * that.canvasWidth;
		that.fontSize16 = (16 / 1000) * that.canvasWidth;
		that.fontSize18 = (18 / 1000) * that.canvasWidth;
		that.fontSize19 = (19 / 1000) * that.canvasWidth;
		that.fontSize20 = (20 / 1000) * that.canvasWidth;
		
		console.log(that.widthRatio,that.heightRatio);
		
		$(that.gCanvas).attr('width',that.canvasWidth).attr('height',that.canvasHeight);
		that.marginL = (15 * that.canvasWidth / 100); /* 10% */
		that.marginR = (0 * that.canvasWidth / 100); /* 30% */
		that.marginT = (0 * that.canvasHeight / 100); /* 10% */
		that.marginB = (15 * that.canvasHeight / 100); /* 10% */
		that.totalWidth = that.gCanvas.width;
		that.totalHeight = that.gCanvas.height;
		that.availWidth = that.totalWidth - that.marginL - that.marginR;
		that.availHeight = that.totalHeight - that.marginT - that.marginB;
		that.totalSegmentsX = 11;
		that.totalSegmentsY = 7;
		that.xUnitWidth = that.availWidth / that.totalSegmentsX;
		that.yUnitWidth = that.availHeight / that.totalSegmentsY;
		//if(!that.isLineMoved){
			that.x1 = that.newX1 = that.marginL + that.diffX;
			that.y1 = that.newY1 = that.marginT+that.availHeight + that.diffY;
			that.x2 = that.newX2 = that.marginL+that.availWidth + that.diffX;
			that.y2 = that.newY2 = that.marginT + that.diffY;
		//}
		
		that.diffX = that.diffY = 0;
		
		/* that.topText = {
			x :  that.marginL+that.availWidth+(that.canvasWidth/18),
			y :  that.marginT
		} */
		
		that.slider.x = that.marginL+that.availWidth+(that.canvasWidth/18);
		that.slider.y = that.marginT;
		that.slider.width = 5;
		that.slider.height = (that.canvasHeight/3);
		
		that.gCanvasContext.font = that.fontSize16+"px Arial";
		var topTextWidth = that.gCanvasContext.measureText("Gelijke verdeling").width;
		var topTextHeight = parseInt(that.gCanvasContext.font.match(/\d+/), 10);
		
		var bufferX =  topTextWidth / 6;
		
		that.knob.x = that.slider.x+bufferX;
		that.knob.y = that.slider.y+topTextHeight+17;
		
		that.knob.yMin = that.slider.y+topTextHeight+17;
		that.knob.yMax = that.slider.y+topTextHeight+17+that.slider.height;
		that.knob.y = that.knob.yMin + ( Math.abs(that.C1) / ( (2.5-0.01) / (that.knob.yMax - that.knob.yMin)  ) );
		
		that.drawCanvas();
		
		var yNumTextWidth = that.gCanvasContext.measureText( ((10)*10) ).width;
		
		$("#resetBtn").css({'font-size':Math.ceil(that.fontSize18)+"px"});
		
		var resetBtnHeight = Math.round( $("#resetBtn").height() );
		
		$("#resetBtn").css({bottom:(that.marginB-(resetBtnHeight+(resetBtnHeight/2)) )+"px",left:yNumTextWidth+"px"});
		
		
		
	}
	
	
	that.drawLegendBox = function(){
		//that.gCanvasContext.save();
		that.gCanvasContext.beginPath();
		//that.gCanvasContext.globalAlpha = 0.8;
		that.gCanvasContext.fillStyle = "#d9953b";
		that.gCanvasContext.rect(that.legendBox.x,that.legendBox.y,that.legendBox.width,that.legendBox.height);
		that.gCanvasContext.fill();
		//that.gCanvasContext.restore();
				
		that.gCanvasContext.beginPath();
		that.gCanvasContext.fillStyle = "#000";
		that.gCanvasContext.font = that.fontSize18+"px Arial";
		that.gCanvasContext.fillText( "Blauw      = Consumentensurplus" , that.legendBox.x+(that.canvasHeight/35) , that.legendBox.y+(that.canvasHeight/20)  );
		that.gCanvasContext.fillText( "Oranje     = Producentensurplus" , that.legendBox.x+(that.canvasHeight/35) , that.legendBox.y+(2*that.canvasHeight/20)  );
		that.gCanvasContext.fillText( "Groen      = Surplus overheid" , that.legendBox.x+(that.canvasHeight/35) , that.legendBox.y+(3*that.canvasHeight/20)  );
		that.gCanvasContext.fillText( "Rood       = Herberger-driehoek" , that.legendBox.x+(that.canvasHeight/35) , that.legendBox.y+(4*that.canvasHeight/20)  );
		
	}
		
	
	this.drawCanvas = function(){
		that.gCanvas.width =  that.gCanvas.width;
		
		// Fill Grid Width Blue Color;
		/* that.gCanvasContext.beginPath();
		that.gCanvasContext.fillStyle = "#E9F6FE";
		that.gCanvasContext.rect(that.marginL,that.marginT,that.availWidth,that.availHeight);
		that.gCanvasContext.fill(); */
		
		//console.log(that.fontSize20);
		
		// Draw "0" Text
		/* that.gCanvasContext.fillStyle = "#000";
		that.gCanvasContext.font = "italic "+that.fontSize18+"px Arial";
		var zeroTextWidth = that.gCanvasContext.measureText( "O" ).width;
		var zeroTextHeight = parseInt(that.gCanvasContext.font.match(/\d+/), 10);
		that.gCanvasContext.fillText( "O" , that.marginL-4-zeroTextWidth , that.marginT+that.availHeight+4+zeroTextHeight ); */
		
		var legendXPos = (that.canvasWidth/18);
		
		// Draw Blue Legends 
		that.gCanvasContext.fillStyle = "#000";
		that.gCanvasContext.font = that.fontSize16+"px Arial";
		var blueLegendTextWidth = that.gCanvasContext.measureText( "Gelijke verdeling" ).width;
		that.gCanvasContext.fillText( "Gelijke verdeling" , that.marginL+that.availWidth+legendXPos , that.marginT+that.availHeight-(that.canvasHeight/5.4)  );
		
		that.gCanvasContext.beginPath();
		that.gCanvasContext.strokeStyle = "#ef3f6b";
		that.gCanvasContext.lineWidth = that.legendLineThickNess;
		that.gCanvasContext.moveTo(that.marginL+that.availWidth+legendXPos+(blueLegendTextWidth/3.7) , that.marginT+that.availHeight-(that.canvasHeight/5.4)+that.legendLineTop);
		that.gCanvasContext.lineTo(that.marginL+that.availWidth+legendXPos+(blueLegendTextWidth/3.7)+(blueLegendTextWidth/2.5),that.marginT+that.availHeight-(that.canvasHeight/5.4)+that.legendLineTop);
		that.gCanvasContext.stroke();
		
		that.blueLegendCircleObj.x = that.marginL+that.availWidth+legendXPos+(blueLegendTextWidth/3.7)+(blueLegendTextWidth/2.5)/2;
		that.blueLegendCircleObj.y = that.marginT+that.availHeight-(that.canvasHeight/5.4)+that.legendLineTop;
		
		if(that.blueLegendCircleObj.isHighLightRequired){
			that.gCanvasContext.save();
			that.gCanvasContext.globalAlpha = 0.25;
			that.gCanvasContext.beginPath();
			that.gCanvasContext.fillStyle = '#ef3f6b';
			that.gCanvasContext.arc(that.marginL+that.availWidth+legendXPos+(blueLegendTextWidth/3.7)+(blueLegendTextWidth/2.5)/2,that.marginT+that.availHeight-(that.canvasHeight/5.4)+that.legendLineTop,(3*that.circleRadius)-1,0,2*Math.PI,false);
			that.gCanvasContext.fill();	
			that.gCanvasContext.restore();
		}
		
		that.gCanvasContext.beginPath();
		//that.gCanvasContext.strokeStyle = '#000';
		that.gCanvasContext.fillStyle = '#ef3f6b';
		that.gCanvasContext.arc(that.marginL+that.availWidth+legendXPos+(blueLegendTextWidth/3.7)+(blueLegendTextWidth/2.5)/2,that.marginT+that.availHeight-(that.canvasHeight/5.4)+that.legendLineTop,that.circleRadius,0,2*Math.PI,false);
		//that.gCanvasContext.stroke();
		that.gCanvasContext.fill();
		
		
		
		// End
		
		// Draw Orange Legends 
		that.gCanvasContext.fillStyle = "#000";
		that.gCanvasContext.font = that.fontSize16+"px Arial";
		var orangeLegendTextWidth = that.gCanvasContext.measureText( "Gelijke verdeling" ).width;
		that.gCanvasContext.fillText( "Niet gelijke verdeling" , that.marginL+that.availWidth+legendXPos , that.marginT+that.availHeight-(that.canvasHeight/20)  );
		
		that.gCanvasContext.beginPath();
		that.gCanvasContext.strokeStyle = "#70bf54";
		that.gCanvasContext.lineWidth = that.legendLineThickNess;
		that.gCanvasContext.moveTo(that.marginL+that.availWidth+legendXPos+(orangeLegendTextWidth/3.7) , that.marginT+that.availHeight-(that.canvasHeight/20)+that.legendLineTop);
		that.gCanvasContext.lineTo(that.marginL+that.availWidth+legendXPos+(orangeLegendTextWidth/3.7)+(orangeLegendTextWidth/2.5),that.marginT+that.availHeight-(that.canvasHeight/20)+that.legendLineTop);
		that.gCanvasContext.stroke();
		
		that.orangeLegendCircleObj.x = that.marginL+that.availWidth+legendXPos+(orangeLegendTextWidth/3.7)+(orangeLegendTextWidth/2.5)/2;
		that.orangeLegendCircleObj.y = that.marginT+that.availHeight-(that.canvasHeight/20)+that.legendLineTop;
		
		if(that.orangeLegendCircleObj.isHighLightRequired){
			that.gCanvasContext.save();
			that.gCanvasContext.globalAlpha = 0.25;
			that.gCanvasContext.beginPath();
			that.gCanvasContext.fillStyle = '#70bf54';
			that.gCanvasContext.arc(that.marginL+that.availWidth+legendXPos+(orangeLegendTextWidth/3.7)+(orangeLegendTextWidth/2.5)/2,that.marginT+that.availHeight-(that.canvasHeight/20)+that.legendLineTop,(3*that.circleRadius)-1,0,2*Math.PI,false);
			that.gCanvasContext.fill();	
			that.gCanvasContext.restore();
		}
		
		that.gCanvasContext.beginPath();
		//that.gCanvasContext.strokeStyle = '#000';
		that.gCanvasContext.fillStyle = '#70bf54';
		that.gCanvasContext.arc(that.marginL+that.availWidth+legendXPos+(orangeLegendTextWidth/3.7)+(orangeLegendTextWidth/2.5)/2,that.marginT+that.availHeight-(that.canvasHeight/20)+that.legendLineTop,that.circleRadius,0,2*Math.PI,false);
		//that.gCanvasContext.stroke();
		that.gCanvasContext.fill();
		// End
			
		
		var xPos = that.marginL;
		var yPos = that.marginT+that.availHeight;
		xNumTextHeight = 0;
		var xNumTextWidth = 0;
		
		for(var i=0;i<that.totalSegmentsX+1;i++){
			
			that.gCanvasContext.beginPath();
			that.gCanvasContext.lineWidth = that.axisLineWidth;
			that.gCanvasContext.strokeStyle = "#000";
			that.gCanvasContext.moveTo(xPos,yPos+2);
			that.gCanvasContext.lineTo(xPos,yPos+7);
			that.gCanvasContext.stroke();
			
			if(i != 0){
				// White Grid Lines 
				that.gCanvasContext.beginPath();
				that.gCanvasContext.lineWidth = that.axisLineWidth;
				that.gCanvasContext.strokeStyle = "#00aeef";
				that.gCanvasContext.moveTo(Math.round(xPos),Math.round(yPos) );
				that.gCanvasContext.lineTo(Math.round(xPos),Math.round(yPos-that.availHeight) );
				that.gCanvasContext.stroke();
			
				/* that.gCanvasContext.fillStyle = "#000";
				that.gCanvasContext.font = that.fontSize16+"px Arial";
				
				xNumTextWidth = that.gCanvasContext.measureText( ((i)*10) ).width;
				xNumTextHeight = parseInt(that.gCanvasContext.font.match(/\d+/), 10);
				
				//console.log( parseInt(that.gCanvasContext.font.match(/\d+/), 10) );
				
				that.gCanvasContext.fillText( ((i)*10) , xPos-(xNumTextWidth/2) , yPos+8+xNumTextHeight  ); */
			}
			
			//console.log(Math.round(xPos));
			
			xPos = xPos + that.xUnitWidth;
		}
		
		var xPos = that.marginL;
		var yPos = that.marginT+that.availHeight;
		var yNumTextHeight = 0;
		var yNumTextWidth = 0;
		
		for(var i=0;i<that.totalSegmentsY+1;i++){
			
			
			that.gCanvasContext.beginPath();
			that.gCanvasContext.lineWidth = that.axisLineWidth;
			that.gCanvasContext.strokeStyle = "#000";
			that.gCanvasContext.moveTo(xPos-2,yPos);
			that.gCanvasContext.lineTo(xPos-7,yPos);
			that.gCanvasContext.stroke();
			
			if(i != 0){
				// White Grid Lines 
				that.gCanvasContext.beginPath();
				that.gCanvasContext.lineWidth = that.axisLineWidth;
				that.gCanvasContext.strokeStyle = "#00aeef";
				that.gCanvasContext.moveTo(Math.round(xPos),Math.round(yPos));
				that.gCanvasContext.lineTo(Math.round(xPos+that.availWidth),Math.round(yPos));
				that.gCanvasContext.stroke();
			
				
				/* that.gCanvasContext.fillStyle = "#000";
				that.gCanvasContext.font = that.fontSize16+"px Arial"
				
				yNumTextWidth = that.gCanvasContext.measureText( ((i)*10) ).width;
				yNumTextHeight = parseInt(that.gCanvasContext.font.match(/\d+/), 10);
				
				that.gCanvasContext.fillText( ((i)*10) , xPos-8-3-yNumTextWidth , yPos+(yNumTextHeight/2)-3 ); */
			}

			yPos = yPos - that.yUnitWidth;
		}
		
		that.drawCurveAndLine();
		
		// x-axis
		that.gCanvasContext.beginPath();
		that.gCanvasContext.lineWidth = that.axisLineWidth;
		that.gCanvasContext.strokeStyle = "#000";
		that.gCanvasContext.setLineDash([]);
		that.gCanvasContext.moveTo(that.marginL-(that.axisLineWidth/2),that.marginT+that.availHeight);
		that.gCanvasContext.lineTo(that.marginL+that.availWidth+(that.axisLineWidth/2),that.marginT+that.availHeight);
		that.gCanvasContext.stroke();

		that.gCanvasContext.fillStyle = "#000";
		that.gCanvasContext.font = ""+that.fontSize18+"px Arial";
		var xAxisTextWidth = that.gCanvasContext.measureText("Hoeveelheid (Q)").width;
		var textHeight = parseInt(that.gCanvasContext.font.match(/\d+/), 10);
		that.gCanvasContext.fillText( "Hoeveelheid (Q)" , that.marginL+that.availWidth-xAxisTextWidth-(that.canvasWidth/8) , that.marginT+that.availHeight+6+xNumTextHeight+textHeight+20  );
		
		// y-axis
		that.gCanvasContext.beginPath();
		that.gCanvasContext.lineWidth = that.axisLineWidth;
		that.gCanvasContext.strokeStyle = "#000";
		that.gCanvasContext.setLineDash([]);
		that.gCanvasContext.moveTo(that.marginL ,that.marginT-(that.axisLineWidth/2));
		that.gCanvasContext.lineTo(that.marginL ,that.marginT+that.availHeight-(that.axisLineWidth/2));
		that.gCanvasContext.stroke();
		
		that.gCanvasContext.fillStyle = "#000";
		that.gCanvasContext.font = ""+that.fontSize18+"px Arial";
		var textHeight = parseInt(that.gCanvasContext.font.match(/\d+/), 10);
		that.gCanvasContext.fillText( "Percentage van het totale inkomen" , that.marginL , that.marginT-textHeight  );
		
		//console.log( (that.marginB+" "+(2*resetBtnHeight) ) )
		
		that.dragCircle.x = that.marginL + (that.line2Points[0].x * that.xUnitWidth);
		that.dragCircle.y = that.marginT + that.availHeight - (that.yUnitWidth*that.line2Points[0].y);
		
		// Draw circle
		that.gCanvasContext.beginPath();
		that.gCanvasContext.fillStyle = '#0089cf';
		that.gCanvasContext.arc(that.dragCircle.x,that.dragCircle.y,that.dragCircle.radius,0,2*Math.PI);
		that.gCanvasContext.fill();
		
		that.drawLegendBox();
	}
	
	
	this.drawCurveAndLine = function(){
		// Form Line between (6,0) and (0,6)
		
		// m = (y2 - y1)/(x2-x1); ------> (6 - 0) / (0 - 6);
		// y-y1 = x-x1 ; y - 0 = -1 * (x - 6); ------> y = 6 - x;
		
		var x1 = that.marginL + (that.xUnitWidth*6);
		var y1 = that.marginT+that.availHeight;
		
		var x2 = that.marginL;
		var y2 = that.marginT+that.availHeight - (that.yUnitWidth*6); 
		
		// Form Line with equation -2x+3y = 3
		that.linePoints = [];
		
		for(var x=0;x<that.totalSegmentsX;x++){
			var y = (3+(2*x) )/3;
			that.linePoints.push({x:x,y:y});
			//console.log(y);
		}
		
		// Form Line with equation (2/3)x + a
		that.line2Points = [];
		
		for(var x=0;x<that.totalSegmentsX;x++){
			var y = (2*x/3) + that.a;
			that.line2Points.push({x:x,y:y});
			//console.log(y);
		}
		
		// Static - Intersection Points 
		for(var x=0;x<that.totalSegmentsX;x++){
			var y11 = 6 - x;
			var y22 = (3+(2*x) )/3;
			if(y11 == y22){
				interSectionPoint.x = x;
				interSectionPoint.y = y11;
			}
		}
		
		// Dynamic - Intersection Points 
		/* for(var x=0;x<4;x+=0.01){
			var y11 = (6 - x).toFixed(2);
			var y22 = ( (2*x/3) + that.a ).toFixed(2);
			//console.log(y11+" "+y22);
			if(y11 == y22){
				interSectionPoint2.x = x.toFixed(2);
				interSectionPoint2.y = y11;
			}
		}	 */
		
		// Both the eqns solved for x and y
		interSectionPoint2.x =  (18 - 3*that.a)/5;
		interSectionPoint2.y =  (12 + 3*that.a)/5;
		
		// 
		interSectionPoint3.x =  interSectionPoint2.x;
		interSectionPoint3.y =  (3+(2*interSectionPoint3.x) )/3;
		
		// Static Intersection coordinates
		var x0Pos = that.marginL + ( interSectionPoint.x * that.xUnitWidth );
		var y0Pos = that.marginT + that.availHeight -(that.yUnitWidth*interSectionPoint.y);
		
		// Static Intersection - Y axis coordinates 
		var x01Pos = that.marginL + ( interSectionPoint.x * that.xUnitWidth );
		var y01Pos = that.marginT + that.availHeight;
		
		// Static Intersection - X axis coordinates
		var x02Pos = that.marginL;
		var y02Pos = that.marginT + that.availHeight -(that.yUnitWidth*interSectionPoint.y);
		
		
		
		//Dynamic Intersection 1 coordinates
		var x1Pos = that.marginL + ( interSectionPoint2.x * that.xUnitWidth );
		var y1Pos = that.marginT + that.availHeight -(that.yUnitWidth*interSectionPoint2.y);
		
		//Dynamic Intersection 1 - Y axis coordinates 
		var x11Pos = that.marginL + ( interSectionPoint2.x * that.xUnitWidth );
		var y11Pos = that.marginT + that.availHeight;
		
		//Dynamic Intersection 1 - X axis coordinates
		var x12Pos = that.marginL;
		var y12Pos = that.marginT + that.availHeight -(that.yUnitWidth*interSectionPoint2.y);
				
		
		//Dynamic Intersection 2 coordinates
		var x2Pos = that.marginL + ( interSectionPoint3.x * that.xUnitWidth );
		var y2Pos = that.marginT + that.availHeight -(that.yUnitWidth*interSectionPoint3.y);
		
		//Dynamic Intersection 2 - Y axis coordinates 
		var x21Pos = that.marginL + ( interSectionPoint3.x * that.xUnitWidth );
		var y21Pos = that.marginT + that.availHeight;
		
		//Dynamic Intersection 2 - X axis coordinates
		var x22Pos = that.marginL;
		var y22Pos = that.marginT + that.availHeight -(that.yUnitWidth*interSectionPoint3.y);
			
			
		// First Traingle - Top 
		that.gCanvasContext.save();
		that.gCanvasContext.beginPath();
		that.gCanvasContext.globalAlpha = 0.75;
		that.gCanvasContext.fillStyle = "#0089cf";
		that.gCanvasContext.moveTo(x2,y2);
		that.gCanvasContext.lineTo(x1Pos,y1Pos);
		that.gCanvasContext.lineTo(x12Pos,y12Pos);
		that.gCanvasContext.lineTo(x2,y2);
		that.gCanvasContext.fill();
		that.gCanvasContext.restore();
		
		
		// Second Traingle - Bottom
		var xStartPos = that.marginL + (that.linePoints[0].x * that.xUnitWidth);
		var yStartPos = that.marginT + that.availHeight - (that.yUnitWidth*that.linePoints[0].y);
		
		that.gCanvasContext.save();
		that.gCanvasContext.beginPath();
		that.gCanvasContext.globalAlpha = 0.75;
		that.gCanvasContext.fillStyle = "#d9953b";
		that.gCanvasContext.moveTo(xStartPos,yStartPos);
		that.gCanvasContext.lineTo(x2Pos,y2Pos);
		that.gCanvasContext.lineTo(x22Pos,y22Pos);
		that.gCanvasContext.lineTo(xStartPos,yStartPos);
		that.gCanvasContext.fill();
		that.gCanvasContext.restore();
		
		
		// Third Traingle - Right 
		that.gCanvasContext.save();
		that.gCanvasContext.beginPath();
		that.gCanvasContext.globalAlpha = 0.75;
		that.gCanvasContext.fillStyle = "#ef3f6b";
		that.gCanvasContext.moveTo(x0Pos,y0Pos);
		that.gCanvasContext.lineTo(x1Pos,y1Pos);
		that.gCanvasContext.lineTo(x2Pos,y2Pos);
		that.gCanvasContext.lineTo(x0Pos,y0Pos);
		that.gCanvasContext.fill();
		that.gCanvasContext.restore();
		
		
		// Rectangle 
		that.gCanvasContext.save();
		that.gCanvasContext.beginPath();
		that.gCanvasContext.globalAlpha = 0.75;
		that.gCanvasContext.fillStyle = "#70bf54";
		that.gCanvasContext.moveTo(x1Pos,y1Pos);
		that.gCanvasContext.lineTo(x12Pos,y12Pos);
		that.gCanvasContext.lineTo(x22Pos,y22Pos);
		that.gCanvasContext.lineTo(x2Pos,y2Pos);
		that.gCanvasContext.lineTo(x1Pos,y1Pos);
		that.gCanvasContext.fill();
		that.gCanvasContext.restore();
				
		// Vertical Dotted line - Intersection
		that.gCanvasContext.beginPath();
		that.gCanvasContext.strokeStyle = "#000";
		that.gCanvasContext.lineWidth = that.curveLineWidth;
		that.gCanvasContext.setLineDash([7,5]);
		that.gCanvasContext.moveTo(x0Pos,y0Pos);
		that.gCanvasContext.lineTo(x01Pos,y01Pos);
		that.gCanvasContext.stroke();
		
		that.gCanvasContext.beginPath();
		that.gCanvasContext.fillStyle = "#000";
		that.gCanvasContext.font = ""+that.fontSize18+"px Arial";
		var textWidth = that.gCanvasContext.measureText("Q").width;
		var textHeight = parseInt(that.gCanvasContext.font.match(/\d+/), 10);
		that.gCanvasContext.fillText("Q",x01Pos-(textWidth/2),y01Pos+textHeight+5);
		
		that.gCanvasContext.beginPath();
		that.gCanvasContext.fillStyle = "#000";
		that.gCanvasContext.font = ""+that.fontSize14+"px Arial";
		var textWidth = that.gCanvasContext.measureText("Q").width;
		var textHeight = parseInt(that.gCanvasContext.font.match(/\d+/), 10);
		that.gCanvasContext.fillText("e",x01Pos+(textWidth/1.5),y01Pos+textHeight+(that.canvasHeight/55));
		
		// Horizontal Dotted line - Intersection
		that.gCanvasContext.beginPath();
		that.gCanvasContext.strokeStyle = "#000";
		that.gCanvasContext.lineWidth = that.curveLineWidth;
		that.gCanvasContext.setLineDash([7,5]);
		that.gCanvasContext.moveTo(x0Pos,y0Pos);
		that.gCanvasContext.lineTo(x02Pos,y02Pos);
		that.gCanvasContext.stroke();
		
		that.gCanvasContext.beginPath();
		that.gCanvasContext.fillStyle = "#000";
		that.gCanvasContext.font = ""+that.fontSize18+"px Arial";
		var textWidth = that.gCanvasContext.measureText("P").width;
		var textHeight = parseInt(that.gCanvasContext.font.match(/\d+/), 10);
		that.gCanvasContext.fillText("P",x02Pos-(textWidth)-(that.canvasWidth/75),y02Pos+(textHeight/3));
				
		that.gCanvasContext.beginPath();
		that.gCanvasContext.fillStyle = "#000";
		that.gCanvasContext.font = ""+that.fontSize14+"px Arial";
		var textWidth = that.gCanvasContext.measureText("e").width;
		var textHeight = parseInt(that.gCanvasContext.font.match(/\d+/), 10);
		that.gCanvasContext.fillText("e",x02Pos-(textWidth)-(that.canvasWidth/150),y02Pos+(textHeight/3)+(that.canvasHeight/100) );
		
		// Draw Line between (x1 y1) and (x2 y2)
		that.gCanvasContext.beginPath();
		that.gCanvasContext.setLineDash([]);
		that.gCanvasContext.strokeStyle = "#0089cf";
		that.gCanvasContext.lineWidth = that.curveLineWidth;
		that.gCanvasContext.moveTo(x1,y1);
		that.gCanvasContext.lineTo(x2,y2);
		that.gCanvasContext.stroke();
		
		// Draw Line for eqn -2x+3y = 3
		for(var i=0;i<that.totalSegmentsX;i++){
			var xPos = that.marginL + (that.linePoints[i].x * that.xUnitWidth);
			var yPos = that.marginT + that.availHeight - (that.yUnitWidth*that.linePoints[i].y);
			if(i==0){
				that.gCanvasContext.beginPath();
				that.gCanvasContext.setLineDash([]);
				that.gCanvasContext.lineWidth = that.curveLineWidth;
				that.gCanvasContext.strokeStyle = '#d9953b';
				that.gCanvasContext.moveTo(xPos,yPos);
			}else{
				that.gCanvasContext.lineTo(xPos,yPos);
			}
		}
		
		that.gCanvasContext.stroke();
		
		// Draw Line for eqn (2/3)x + a
		for(var i=0;i<that.totalSegmentsX;i++){
			var xPos = that.marginL + (that.line2Points[i].x * that.xUnitWidth);
			var yPos = that.marginT + that.availHeight - (that.yUnitWidth*that.line2Points[i].y);
			if(i==0){
				that.gCanvasContext.beginPath();
				that.gCanvasContext.setLineDash([]);
				that.gCanvasContext.lineWidth = that.curveLineWidth;
				that.gCanvasContext.strokeStyle = '#0089cf';
				that.gCanvasContext.moveTo(xPos,yPos);
			}else{
				that.gCanvasContext.lineTo(xPos,yPos);
			}
		}
		
		that.gCanvasContext.stroke();
		
		
		// Dynamic Vertical Dotted line - Intersection
		that.gCanvasContext.beginPath();
		that.gCanvasContext.strokeStyle = "#000";
		that.gCanvasContext.lineWidth = that.curveLineWidth;
		that.gCanvasContext.setLineDash([7,5]);
		that.gCanvasContext.moveTo(x1Pos,y1Pos);
		that.gCanvasContext.lineTo(x11Pos,y11Pos);
		that.gCanvasContext.stroke();
		
		that.gCanvasContext.beginPath();
		that.gCanvasContext.fillStyle = "#000";
		that.gCanvasContext.font = ""+that.fontSize18+"px Arial";
		var textWidth = that.gCanvasContext.measureText("Q").width;
		var textHeight = parseInt(that.gCanvasContext.font.match(/\d+/), 10);
		that.gCanvasContext.fillText("Q",x11Pos-(textWidth/2),y11Pos+textHeight+5);
		
		that.gCanvasContext.beginPath();
		that.gCanvasContext.fillStyle = "#000";
		that.gCanvasContext.font = ""+that.fontSize14+"px Arial";
		var textWidth = that.gCanvasContext.measureText("Q").width;
		var textHeight = parseInt(that.gCanvasContext.font.match(/\d+/), 10);
		that.gCanvasContext.fillText("1",x11Pos+(textWidth/1.5),y11Pos+textHeight+(that.canvasHeight/60));
		
		// Dynamic Horizontal Dotted line - Intersection
		that.gCanvasContext.beginPath();
		that.gCanvasContext.strokeStyle = "#000";
		that.gCanvasContext.lineWidth = that.curveLineWidth;
		that.gCanvasContext.setLineDash([7,5]);
		that.gCanvasContext.moveTo(x1Pos,y1Pos);
		that.gCanvasContext.lineTo(x12Pos,y12Pos);
		that.gCanvasContext.stroke();
		
		that.gCanvasContext.beginPath();
		that.gCanvasContext.fillStyle = "#000";
		that.gCanvasContext.font = ""+that.fontSize18+"px Arial";
		var textWidth = that.gCanvasContext.measureText("P").width;
		var textHeight = parseInt(that.gCanvasContext.font.match(/\d+/), 10);
		that.gCanvasContext.fillText("P",x12Pos-(textWidth)-(that.canvasWidth/75),y12Pos+(textHeight/3));
		
		that.gCanvasContext.beginPath();
		that.gCanvasContext.fillStyle = "#000";
		that.gCanvasContext.font = ""+that.fontSize14+"px Arial";
		var textWidth = that.gCanvasContext.measureText("1").width;
		var textHeight = parseInt(that.gCanvasContext.font.match(/\d+/), 10);
		that.gCanvasContext.fillText("1",x12Pos-(textWidth)-(that.canvasWidth/150),y12Pos+(textHeight/3)+(that.canvasHeight/100) );
		
		// Dynamic Horizontal Dotted line - Intersection
		/* that.gCanvasContext.beginPath();
		that.gCanvasContext.strokeStyle = "#000";
		that.gCanvasContext.lineWidth = that.curveLineWidth;
		that.gCanvasContext.setLineDash([7,5]);
		that.gCanvasContext.moveTo(x2Pos,y2Pos);
		that.gCanvasContext.lineTo(x22Pos,y22Pos);
		that.gCanvasContext.stroke(); */
		
		that.drawDottedLines(x2Pos,y2Pos,x22Pos,y22Pos);
		
		that.gCanvasContext.beginPath();
		that.gCanvasContext.fillStyle = "#000";
		that.gCanvasContext.font = ""+that.fontSize18+"px Arial";
		var textWidth = that.gCanvasContext.measureText("P").width;
		var textHeight = parseInt(that.gCanvasContext.font.match(/\d+/), 10);
		that.gCanvasContext.fillText("P",x22Pos-(textWidth)-(that.canvasWidth/75),y22Pos+(textHeight/3));
		
		
		that.gCanvasContext.beginPath();
		that.gCanvasContext.fillStyle = "#000";
		that.gCanvasContext.font = ""+that.fontSize14+"px Arial";
		var textWidth = that.gCanvasContext.measureText("s").width;
		var textHeight = parseInt(that.gCanvasContext.font.match(/\d+/), 10);
		that.gCanvasContext.fillText("s",x22Pos-(textWidth)-(that.canvasWidth/150),y22Pos+(textHeight/3)+(that.canvasHeight/100) );
		
		
		var textYpos = that.marginT + that.availHeight - (that.yUnitWidth*that.line2Points[0].y)-(2*that.yUnitWidth)
		
		that.gCanvasContext.beginPath();
		that.gCanvasContext.fillStyle = "#000";
		that.gCanvasContext.font = ""+that.fontSize18+"px Arial";
		var textHeight = parseInt(that.gCanvasContext.font.match(/\d+/), 10);
		that.gCanvasContext.fillText("Aanbod na accijns",x0Pos+5,textYpos+textHeight);
		
		var textXpos = that.marginL + (6*that.xUnitWidth);
		var textYpos = that.marginT + that.availHeight - (5*that.yUnitWidth);
		
		that.gCanvasContext.beginPath();
		that.gCanvasContext.fillStyle = "#000";
		that.gCanvasContext.font = ""+that.fontSize18+"px Arial";
		var textHeight = parseInt(that.gCanvasContext.font.match(/\d+/), 10);
		that.gCanvasContext.fillText("Aanbod",textXpos+5,textYpos+textHeight);
		
		var textXpos = that.marginL ;
		var textYpos = that.marginT + that.availHeight - (6*that.yUnitWidth);
		
		that.gCanvasContext.beginPath();
		that.gCanvasContext.fillStyle = "#000";
		that.gCanvasContext.font = ""+that.fontSize18+"px Arial";
		var textWidth = that.gCanvasContext.measureText("Prijis (p)").width;
		var textHeight = parseInt(that.gCanvasContext.font.match(/\d+/), 10);
		that.gCanvasContext.fillText("Prijis (p)",textXpos-textWidth-(that.canvasWidth/35),textYpos-(that.canvasHeight/20) );
		
		
	}
	
	
	this.drawDottedLines = function(x1,y1,x2,y2){
		that.gCanvasContext.beginPath();
		that.gCanvasContext.strokeStyle = "#000";
		that.gCanvasContext.lineWidth = that.curveLineWidth;
		that.gCanvasContext.setLineDash([7,5]);
		that.gCanvasContext.moveTo(x1,y1);
		that.gCanvasContext.lineTo(x2,y2);
		that.gCanvasContext.stroke();	
	}
	
	this.openFullscreen = function() {
	  
	  if(!that.isFullScreenEnabled){
			  var elem = document.getElementById("mainContainer");
			  if (elem.requestFullscreen) {
				elem.requestFullscreen();
			  } else if (elem.mozRequestFullScreen) { /* Firefox */
				elem.mozRequestFullScreen();
			  } else if (elem.webkitRequestFullscreen) { /* Chrome, Safari & Opera */
				elem.webkitRequestFullscreen();
			  } else if (elem.msRequestFullscreen) { /* IE/Edge */
				console.log("msRequestFullscreen");
				elem.msRequestFullscreen();
			  }
			  
			  $("#fullScreenImage").hide();
			  $("#exitScreenImage").show();
			  
			  that.isFullScreenEnabled  = true;
			  
			 /* setTimeout(function(){
				  that.setCanvasSize();
			  },300); */
	  }else{
			var elem = document;
		
			if (elem.exitFullscreen) {
				elem.exitFullscreen();
			} else if (elem.mozCancelFullScreen) { /* Firefox */
				elem.mozCancelFullScreen();
			} else if (elem.webkitExitFullscreen) { /* Chrome, Safari and Opera */
				elem.webkitExitFullscreen();
			} else if (elem.msExitFullscreen) { /* IE/Edge */
				elem.msExitFullscreen();
			}	
			
			$("#fullScreenImage").show();
			$("#exitScreenImage").hide();
			
			that.isFullScreenEnabled = false;
			
			/* setTimeout(function(){
			  that.setCanvasSize();
			},300) */;	  
	  }
		  
	}
	
	
	
}