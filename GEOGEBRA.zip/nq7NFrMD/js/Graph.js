var Graph = function(){
	
	var that = this;
	
	that.isIPAD = (/iPad|iPhone/i.test(navigator.userAgent));
	that.isAndroid = navigator.userAgent.toLowerCase().indexOf("android") > -1; 
	that.canvasWidth = 960;
	that.canvasHeight = 599;	
	that.C1 = -0.37;
	that.isMouseDown = false;
	that.isMouseDown2 = false;
	that.isMouseDown3 = false;
	that.isGreenCircleHighLightRequired = false; 
	that.isOrangeCircleHighLightRequired = false;
	that.isBlackCircleHighLightRequired = false;
	that.yellowCircleIndex = null;
	that.isFullScreenEnabled = false;
	that.Y1 = that._Y1 = 0;
	that.X1 = that._X1 = 0;
	that.diffX = that._diffX = 0;
	that.diffY = that._diffY = 0;
	that.x1 = 0;
	that.y1 = 0;
	that.marginL = 0;
	that.marginR = 0;
	that.marginT = 0;
	that.marginB = 0;
	that.totalWidth = 0;
	that.totalHeight = 0;
	that.availWidth = that.totalWidth - that.marginL - that.marginR;
	that.availHeight = that.totalHeight - that.marginT - that.marginB;
	that.isLineMoved = false;
	that.slider = {mousedown:false};
	that.knob = {};
	
	that.a = 3/4;
	that.a2 = 1;
	that.a3 = 1;
	
	that.m = 1;
	
	that.dragCircle = {x:0,y:0,radius:0};
	that.dragCircle2 = {x:0,y:0,radius:0};
	that.dragCircle3 = {x:0,y:0,radius:0};
	
	var interSectionPoint = {x:0,y:0};
	var interSectionPoint2 = {x:0,y:0};
	var interSectionPoint3 = {x:0,y:0};
	
	that.legendBox = {};
	that.legendBox.diffX = 0;
	that.legendBox.diffY = 0;
	that.legendBox.width = 300;
	that.legendBox.height = 150;
	that.legendBox.x = that.canvasWidth - that.legendBox.width - ( that.canvasWidth / 5 );
	that.legendBox.y = that.canvasHeight / 60;
	that.legendBox.mouseDown = false;
	that.legendBox.shown = false;
	
	that.isBlueLineHighLightRequired = false; 
	that.isOrangeLineHighLightRequired = false; 
	
	that.isDottedVL1HighLightRequired = false;
	that.isDottedVL2HighLightRequired = false;
	that.isDottedVL3HighLightRequired = false;
	
	that.isDottedHLHighLightRequired = false;
		
	that.isGreenBoxHighLightRequired = false;
	
	this.init = function(){
		that.gCanvas = document.getElementById("graphCanvas");
		that.gCanvasContext = that.gCanvas.getContext('2d');
		
		//alert(that.isAndroid);
		
		if(that.isIPAD || that.isAndroid){
			$(that.gCanvas).off('touchstart').on('touchstart',that.onCanvasMouseDown);
			$(that.gCanvas).off('touchend').on('touchend',that.onCanvasMouseUp);
			$(that.gCanvas).off('touchmove').on('touchmove',that.onCanvasMouseMove);
			$("#fullScreenBtn").hide();
		}else{
			$(that.gCanvas).off('mousedown').on('mousedown',that.onCanvasMouseDown);
			$(document).off('mouseup').on('mouseup',that.onCanvasMouseUp);
			$(that.gCanvas).off('mousemove').on('mousemove',that.onCanvasMouseMove);
			$("#fullScreenBtn").show();
		}
		
		$("#resetBtn").off('click').on('click',that.onResetBtnClick);
		$("#fullScreenBtn").off('click').on('click',that.openFullscreen);
		
		$("#fullScreenBtn").off('mouseover').on('mouseover',that.onBtnMouseOver);
		$("#fullScreenBtn").off('mouseout').on('mouseout',that.onBtnMouseOut);
		
		$("#checkBox").off('change').on('change',that.onCheckBoxClick);
				
		document.addEventListener("fullscreenchange",that.onActivityFullScreen);
		document.addEventListener("mozfullscreenchange",that.onActivityFullScreen);
		document.addEventListener("webkitfullscreenchange",that.onActivityFullScreen);
		document.addEventListener("MSFullscreenChange",that.onActivityFullScreen);
		
		$("#canvasSliderKnob").off('focus').on('focus',that.onKnobFocus);
		$("#canvasSliderKnob").off('blur').on('blur',that.onKnobBlur);
		
		$(document).off('keydown').on('keydown',that.onDocumentKeyDown);
		
		$("#exitScreenImage").hide();

		//that.initSlider();
		that.setCanvasSize();
		
	}
		
	this.onCheckBoxClick = function(){
		that.legendBox.shown = $(this).prop('checked');	
		that.drawCanvas();
	}
	
	
	this.onDocumentKeyDown = function(e){
		console.log(e.keyCode+" "+that.isKnobFocused);
		
		if(that.isKnobFocused){
			if(e.keyCode == 38){
				that.onKnobMove(that.knob.y-1);
			}else if(e.keyCode == 40){
				that.onKnobMove(that.knob.y+1);
			}
		}
	}
	
	this.onKnobFocus = function(){
		that.isKnobFocused = true;
		that.drawCanvas();
	}
	
	this.onKnobBlur = function(){
		that.isKnobFocused = false;	
		that.drawCanvas();
	}
	
	this.onBtnMouseOver = function(){
		$("#fullScreenBtn").css({backgroundColor:"#eee"});	
		$("#fullScreenBtn img").css({opacity:1});	
	}
	
	this.onBtnMouseOut = function(){
		$("#fullScreenBtn").css({background:"#fff"});	
		$("#fullScreenBtn img").css({opacity:0.5});			
	}
	
	
	this.onActivityFullScreen = function(){
		if ( document.fullscreenElement || document.webkitFullscreenElement || document.mozFullScreenElement || document.msFullscreenElement ) {
			 $("#fullScreenImage").hide();
			 $("#exitScreenImage").show();
			 that.isFullScreenEnabled  = true;	
			 that.setCanvasSize();
		}else{
			$("#fullScreenImage").show();
			$("#exitScreenImage").hide();
			that.isFullScreenEnabled  = false;	
			that.setCanvasSize();
		}
	}
	
	this.onResetBtnClick = function(){
		that.isMouseDown = false;
		that.isMouseDown2 = false;
		that.isMouseDown3 = false;
		that.isOrangeCircleHighLightRequired = that.isBlackCircleHighLightRequired = that.isGreenCircleHighLightRequired = that.isGreenLineHighLightRequired = that.isOrangeLineHighLightRequired = that.isBlueLineHighLightRequired = that.isDottedHLHighLightRequired = that.isDottedVL1HighLightRequired = that.isDottedVL2HighLightRequired = that.isDottedVL3HighLightRequired = that.isGreenBoxHighLightRequired = false;
		that.a = 3/4;
		that.a2 = 1;
		that.a3 = 1;
		that.m = 1;
		that.drawCanvas();
	}

	this.onCanvasMouseDown = function(e){
		
		e.preventDefault();
		
		var touch = e.originalEvent && e.originalEvent.touches && e.originalEvent.touches[0];
		e = touch || e;
		
		var mouseX = e.pageX - $(that.gCanvas).offset().left;
		var mouseY = e.pageY - $(that.gCanvas).offset().top;
		
		//that.diffX = 0;
		//that.diffY = 0;
		
		//console.log(mouseX,mouseY);
		
		that.isOrangeCircleHighLightRequired = that.isBlackCircleHighLightRequired = that.isGreenCircleHighLightRequired = that.isGreenLineHighLightRequired = that.isOrangeLineHighLightRequired = that.isBlueLineHighLightRequired = that.isDottedHLHighLightRequired = that.isDottedVL1HighLightRequired = that.isDottedVL2HighLightRequired = that.isDottedVL3HighLightRequired = that.isGreenBoxHighLightRequired = false;
		
		var convertedX = (mouseX - that.marginL)/ that.xUnitWidth;
		convertedX = Number( convertedX.toFixed(2) );
		
		var convertedY = ( (that.marginT + that.availHeight) - mouseY)/ that.yUnitWidth;
		convertedY = Number( convertedY.toFixed(2) );
		
		console.log(convertedX,convertedY);
		
		//y = mx;
		var curEqnConstant1 = (convertedY) - (that.m*convertedX);
		if( Math.abs(curEqnConstant1) <= 0.1 ){
			console.log("With in the limit1");		
			that.isOrangeLineHighLightRequired = true;
			
			that.isGreenLineHighLightRequired = that.isOrangeCircleHighLightRequired = that.isBlackCircleHighLightRequired = that.isGreenCircleHighLightRequired = that.isBlueLineHighLightRequired = that.isDottedHLHighLightRequired  = that.isDottedVL1HighLightRequired = that.isDottedVL2HighLightRequired = that.isDottedVL3HighLightRequired = false;
		}
		
		//y = a
		var curEqnConstant2 = convertedY;
		if( Math.abs(that.a-curEqnConstant2) <= 0.1 ){
			console.log("With in the limit2");
			that.isGreenLineHighLightRequired = true;
			
			that.isOrangeCircleHighLightRequired = that.isBlackCircleHighLightRequired = that.isGreenCircleHighLightRequired = that.isBlueLineHighLightRequired = that.isOrangeLineHighLightRequired = that.isDottedHLHighLightRequired = that.isDottedVL1HighLightRequired = that.isDottedVL2HighLightRequired =that.isDottedVL3HighLightRequired = false;
		}
		
		//y = mx + c
		var curEqnConstant3 = (convertedY) - (that.m*convertedX);
		if( Math.abs(curEqnConstant3-that.a) <= 0.1 ){
			console.log("With in the limit3");
			that.isBlueLineHighLightRequired = true;
			
			that.isGreenLineHighLightRequired = that.isOrangeCircleHighLightRequired = that.isBlackCircleHighLightRequired = that.isGreenCircleHighLightRequired = that.isOrangeLineHighLightRequired = that.isDottedHLHighLightRequired = that.isDottedVL1HighLightRequired = that.isDottedVL2HighLightRequired = that.isDottedVL3HighLightRequired = false;
		}
		
		//console.log(curEqnConstant3);
		
		// interSectionPoint2
		if( Math.abs(interSectionPoint2.x - convertedX) <= 0.1 && (interSectionPoint2.y > convertedY) && (0 < interSectionPoint2.y)  ){
			that.isDottedVL1HighLightRequired = true;		

			that.isGreenLineHighLightRequired = that.isOrangeCircleHighLightRequired = that.isBlackCircleHighLightRequired = that.isGreenCircleHighLightRequired = that.isOrangeLineHighLightRequired = that.isBlueLineHighLightRequired = that.isDottedHLHighLightRequired = that.isDottedVL2HighLightRequired = that.isDottedVL3HighLightRequired = false;
		}
		
		if( Math.abs(interSectionPoint2.y - convertedY) <= 0.1 && (interSectionPoint2.x > convertedX) && (0 < interSectionPoint2.x)  ){
			that.isDottedHLHighLightRequired = true;		

			that.isGreenLineHighLightRequired = that.isOrangeCircleHighLightRequired = that.isBlackCircleHighLightRequired = that.isGreenCircleHighLightRequired = that.isOrangeLineHighLightRequired = that.isBlueLineHighLightRequired = that.isDottedVL2HighLightRequired = that.isDottedVL3HighLightRequired = false;
		}
		
		
		// Drag circle2
		var xMin = that.dragCircle2.x - that.dragCircle2.radius;
		var xMax = that.dragCircle2.x + that.dragCircle2.radius;
		
		var yMin = that.dragCircle2.y - that.dragCircle2.radius;
		var yMax = that.dragCircle2.y + that.dragCircle2.radius;
		
		if( (xMin < mouseX) && (xMax > mouseX) && (yMin < mouseY) && (mouseY < yMax) ){
			that.isMouseDown2 = true;
			that.isOrangeCircleHighLightRequired = true;
			
			console.log( "dragCircle2" );
			
			that.isGreenLineHighLightRequired = that.isBlackCircleHighLightRequired = that.isGreenCircleHighLightRequired = that.isOrangeLineHighLightRequired = that.isBlueLineHighLightRequired = that.isDottedVL1HighLightRequired = that.isDottedVL2HighLightRequired = that.isDottedHLHighLightRequired = that.isDottedVL3HighLightRequired = false;
		}
		
		// Drag circle3
		var xMin = that.dragCircle3.x - that.dragCircle3.radius;
		var xMax = that.dragCircle3.x + that.dragCircle3.radius;
		
		var yMin = that.dragCircle3.y - that.dragCircle3.radius;
		var yMax = that.dragCircle3.y + that.dragCircle3.radius;
		
		if( (xMin < mouseX) && (xMax > mouseX) && (yMin < mouseY) && (mouseY < yMax) ){
			that.isMouseDown3 = true;
			that.isBlackCircleHighLightRequired = true;
			
			console.log( "dragCircle3" );
			
			that.isGreenLineHighLightRequired = that.isOrangeCircleHighLightRequired = that.isGreenCircleHighLightRequired = that.isOrangeLineHighLightRequired = that.isBlueLineHighLightRequired = that.isDottedVL1HighLightRequired = that.isDottedVL2HighLightRequired = that.isDottedHLHighLightRequired = that.isDottedVL3HighLightRequired = false;
		}
		
		// Drag circle
		var xMin = that.dragCircle.x - that.dragCircle.radius;
		var xMax = that.dragCircle.x + that.dragCircle.radius;
		
		var yMin = that.dragCircle.y - that.dragCircle.radius;
		var yMax = that.dragCircle.y + that.dragCircle.radius;
		
		if( (xMin < mouseX) && (xMax > mouseX) && (yMin < mouseY) && (mouseY < yMax) ){
			that.isMouseDown = true;
			that.isMouseDown2 = false;
			that.isMouseDown3 = false;
			
			that.isGreenCircleHighLightRequired = true;
			
			that.isGreenLineHighLightRequired = that.isOrangeCircleHighLightRequired = that.isBlackCircleHighLightRequired = that.isOrangeLineHighLightRequired = that.isBlueLineHighLightRequired = that.isDottedVL1HighLightRequired = that.isDottedVL2HighLightRequired = that.isDottedHLHighLightRequired =  that.isDottedVL3HighLightRequired = false;
		}
		
		//console.log(that.isMouseDown,that.isMouseDown2,that.isMouseDown3);
		
		
		// Legend Box
		var xMin = that.legendBox.x;
		var xMax = that.legendBox.x + that.legendBox.width;
				
		var yMin = that.legendBox.y;
		var yMax = that.legendBox.y + that.legendBox.height;
		
		if( (xMin < mouseX) && (xMax > mouseX) && (yMin < mouseY) && (mouseY < yMax) ){
			that.legendBox.mouseDown = true;
			that.legendBox.diffX = mouseX - that.legendBox.x;
			that.legendBox.diffY = mouseY - that.legendBox.y;
		}
		
		that.drawCanvas();
	}

	this.onCanvasMouseMove = function(e){
		
		e.preventDefault();
		
		var touch = e.originalEvent && e.originalEvent.touches && e.originalEvent.touches[0];
		e = touch || e;
		
		var mouseX = e.pageX - $(that.gCanvas).offset().left;
		var mouseY = e.pageY - $(that.gCanvas).offset().top;
		
		var convertedX = (mouseX - that.marginL)/ that.xUnitWidth;
		convertedX = Number( convertedX.toFixed(6) );
		
		var convertedY = ( (that.marginT + that.availHeight) - mouseY)/ that.yUnitWidth;
		convertedY = Number( convertedY.toFixed(6) );

		if(that.isMouseDown3){
			if( (convertedX >= 0) && (convertedX <= that.totalSegmentsX)){
				that.a3 = convertedX;
			}
		}
		
		if(that.isMouseDown2){
			if( (convertedY >= 0.2) && (convertedY <= 3)){
				that.a2 = convertedY;
			}
		}
		
		if(that.isMouseDown){
			if( (convertedY >= 0) && (convertedY <= 5)){
				that.a = convertedY;
			}
		}
		
		//console.log(convertedY,that.a,that.a2,that.a3);
		
		if(that.legendBox.mouseDown){
			that.legendBox.x = mouseX - that.legendBox.diffX;
			that.legendBox.y = mouseY - that.legendBox.diffY;
		}
		
		that.drawCanvas();
	}
		
		
	this.onCanvasMouseUp = function(e){
		
		e.preventDefault();
		
		var touch = e.originalEvent && e.originalEvent.touches && e.originalEvent.touches[0];
		e = touch || e;
		
		var mouseX = e.pageX - $(that.gCanvas).offset().left;
		var mouseY = e.pageY - $(that.gCanvas).offset().top;
		
		var convertedX = (mouseX - that.marginL)/ that.xUnitWidth;
		convertedX = Number( convertedX.toFixed(6) );
		
		var convertedY = ( (that.marginT + that.availHeight) - mouseY)/ that.yUnitWidth;
		convertedY = Number( convertedY.toFixed(6) );
		
		//console.log(that.isMouseDown);
		
		if(that.isMouseDown3){
			//if( (convertedY >= 5.5) && (convertedY <= 7)){
				that.a3 = convertedX;
			//}
		}
		
		if(that.isMouseDown2){
			if( (convertedY >= 0.2) && (convertedY <= 3)){
				that.a2 = convertedY;
			}
		}
		
		if(that.isMouseDown){
			if( (convertedY >= 0) && (convertedY <= 5)){
				that.a = convertedY;
			}
		}
		
		//console.log(that.a,that.a2,that.a3);
		
		//that.isBlueLineHighLightRequired = false;	
		that.drawCanvas();
		that.isMouseDown = false;
		that.isMouseDown2 = false;
		that.isMouseDown3 = false;
		
		that.x1 = that.newX1;
		that.y1 = that.newY1; 
		
		that.x2 = that.newX2;
		that.y2 = that.newY2;
		
		that.clickedX =  mouseX;
		that.clickedY =  mouseY;
		
		that.diffX = 0;
		that.diffY = 0;
		
		that.legendBox.mouseDown = false;
		
		that.slider.mousedown = false;
		//that.isKnobFocused = false;
	}
	
	this.setCanvasSize = function(){
		if(that.isFullScreenEnabled){
			
			console.log(that.x1 - that.marginL , that.y1 - (that.marginT+that.availHeight) );
			
			var lastX = that.x1 - that.marginL;
			var lastY = that.y1 - (that.marginT+that.availHeight);
			
			that.prevWidth = that.canvasWidth;
			that.prevHeight = that.canvasHeight;
			
			that.canvasWidth = screen.width;
			that.canvasHeight = screen.height;
			
			that.widthRatio = that.canvasWidth / that.prevWidth;
			that.heightRatio = that.canvasHeight / that.prevHeight;
			
			that.diffX = lastX * that.widthRatio;
			that.diffY = lastY * that.heightRatio;
			
			$("#mainContainer").width(that.canvasWidth).height(that.canvasHeight);
			
			that.axisLineWidth = 2.5;
			that.dividerLineWidth = 4;
			that.curveLineWidth = 4.6;
			that.dragCircle.radius = that.dragCircle2.radius = that.dragCircle3.radius = 7;
			that.legendLineTop = 30;
			that.legendLineThickNess = 3;
			
			that.legendBox.width = 540;
			that.legendBox.height = 400;
			
			that.legendBox.x = that.legendBox.x * that.widthRatio;
			that.legendBox.y = that.legendBox.y * that.heightRatio;
			
			$(".check_box_container").addClass('full-screen-check-box');
			
		}else{
			
			//console.log(that.x1 - that.marginL , that.y1 - (that.marginT+that.availHeight) );
			
			var lastX = that.x1 - that.marginL;
			var lastY = that.y1 - (that.marginT+that.availHeight);
			
			that.prevWidth = that.canvasWidth;
			that.prevHeight = that.canvasHeight;
			
			that.canvasWidth = 960;
			that.canvasHeight = 599;

			that.widthRatio = that.canvasWidth / that.prevWidth;
			that.heightRatio = that.canvasHeight / that.prevHeight;
			
			that.axisLineWidth = 1.5;
			that.dividerLineWidth = 3;
			that.curveLineWidth = 2.6;
			that.dragCircle.radius = that.dragCircle2.radius = that.dragCircle3.radius = 5;
			that.legendLineTop = 20;
			that.legendLineThickNess = 1.5;
			
			that.diffX = lastX * that.widthRatio;
			that.diffY = lastY * that.heightRatio;
			
			$("#mainContainer").width(that.canvasWidth).height(that.canvasHeight);
			
			that.legendBox.width = 300;
			that.legendBox.height = 230;
			
			that.legendBox.x = that.legendBox.x * that.widthRatio;
			that.legendBox.y = that.legendBox.y * that.heightRatio;
			
			$(".check_box_container").removeClass('full-screen-check-box');
						
		}
		
		//that.canvasWidth = 960;
		//that.canvasHeight = 599;
		
		that.fontSize14 = (14 / 1000) * that.canvasWidth;
		that.fontSize15 = (15 / 1000) * that.canvasWidth;
		that.fontSize16 = (16 / 1000) * that.canvasWidth;
		that.fontSize18 = (18 / 1000) * that.canvasWidth;
		that.fontSize19 = (19 / 1000) * that.canvasWidth;
		that.fontSize20 = (20 / 1000) * that.canvasWidth;
		
		console.log(that.widthRatio,that.heightRatio);
		
		$(that.gCanvas).attr('width',that.canvasWidth).attr('height',that.canvasHeight);
		that.marginL = (20 * that.canvasWidth / 100); /* 10% */
		that.marginR = (0 * that.canvasWidth / 100); /* 30% */
		that.marginT = (-1 * that.canvasHeight / 100); /* 10% */
		that.marginB = (15 * that.canvasHeight / 100); /* 10% */
		that.totalWidth = that.gCanvas.width;
		that.totalHeight = that.gCanvas.height;
		that.availWidth = that.totalWidth - that.marginL - that.marginR;
		that.availHeight = that.totalHeight - that.marginT - that.marginB;
		that.totalSegmentsX = 13;
		that.totalSegmentsY = 8;
		that.gridBufferX = (that.canvasWidth)/6;
		that.gridBufferY = (that.canvasHeight)/8;
		that.xUnitWidth = (that.availWidth+that.gridBufferX) / that.totalSegmentsX;
		that.yUnitWidth = (that.availHeight+that.gridBufferY) / that.totalSegmentsY;
		//if(!that.isLineMoved){
			that.x1 = that.newX1 = that.marginL + that.diffX;
			that.y1 = that.newY1 = that.marginT+that.availHeight + that.diffY;
			that.x2 = that.newX2 = that.marginL+that.availWidth + that.diffX;
			that.y2 = that.newY2 = that.marginT + that.diffY;
		//}
		
		that.diffX = that.diffY = 0;
		that.drawCanvas();
		
		var yNumTextWidth = that.gCanvasContext.measureText( ((10)*10) ).width;
		
		$("#resetBtn,.check_box_container").css({'font-size':Math.ceil(that.fontSize18)+"px"});
		var resetBtnHeight = Math.round( $("#resetBtn").height() );
		$("#resetBtn").css({bottom:(that.marginB+(resetBtnHeight/4) )+"px",left:yNumTextWidth+"px"});
		$(".check_box_container").css({bottom:(that.marginB-(3*resetBtnHeight) )+"px",left:yNumTextWidth+"px"});
		
		//$(".checkmark").width(that.checkBoxSize).height(that.checkBoxSize);
	}
	
	
	that.drawLegendBox = function(){
		
		that.gCanvasContext.beginPath();
		that.gCanvasContext.fillStyle = "#70bf54";
		that.gCanvasContext.rect(that.legendBox.x,that.legendBox.y,that.legendBox.width,that.legendBox.height);
		that.gCanvasContext.fill();
				
		that.gCanvasContext.beginPath();
		that.gCanvasContext.fillStyle = "#000";
		that.gCanvasContext.font = that.fontSize18+"px Arial";
		that.gCanvasContext.fillText( "TK=TVK+TCK" , that.legendBox.x+(that.canvasHeight/35) , that.legendBox.y+(that.canvasHeight/20)  );
		that.gCanvasContext.fillText( "TK="+Math.round(that.a2*100)+"q + "+Math.round(that.a*4*100*1000) , that.legendBox.x+(that.canvasHeight/35) , that.legendBox.y+(2*that.canvasHeight/18)  );
		
		that.gCanvasContext.fillText( "Hoeveelheid" , that.legendBox.x+(that.canvasHeight/35) , that.legendBox.y+(3*that.canvasHeight/17)  );
		that.gCanvasContext.fillText( "Totale kosten" , that.legendBox.x+(that.canvasHeight/35) , that.legendBox.y+(4*that.canvasHeight/17)  );
		that.gCanvasContext.fillText( "Constante kosten" , that.legendBox.x+(that.canvasHeight/35) , that.legendBox.y+(5*that.canvasHeight/17)  );
		that.gCanvasContext.fillText( "Variabele kosten", that.legendBox.x+(that.canvasHeight/35) , that.legendBox.y+(6*that.canvasHeight/17)  );
	
		that.gCanvasContext.beginPath();
		that.gCanvasContext.fillStyle = "#000";
		that.gCanvasContext.font = that.fontSize18+"px Arial";//+Math.round(that.a*100)
		that.gCanvasContext.fillText( " = "+Math.round(interSectionPoint2.x*1000*2)+" kg" , that.legendBox.x+(that.canvasHeight/3.5) , that.legendBox.y+(3*that.canvasHeight/17)  );
		that.gCanvasContext.fillText( " = €"+( Math.round(that.a*4*100*1000) + Math.round(interSectionPoint2.x*100000*2) ) , that.legendBox.x+(that.canvasHeight/3.5) , that.legendBox.y+(4*that.canvasHeight/17)  );
		that.gCanvasContext.fillText( " = €"+Math.round(that.a*4*100*1000) , that.legendBox.x+(that.canvasHeight/3.5) , that.legendBox.y+(5*that.canvasHeight/17)  );
		that.gCanvasContext.fillText( " = €"+Math.round(interSectionPoint2.x*100000*2) , that.legendBox.x+(that.canvasHeight/3.5) , that.legendBox.y+(6*that.canvasHeight/17)  );
		
		//that.gCanvasContext.fillText( "=   −4p + "+Math.round(that.a3*100) , that.legendBox.x+(that.canvasHeight/12) , that.legendBox.y+(that.canvasHeight/20)  );
		//that.gCanvasContext.fillText( "=" , that.legendBox.x+(that.canvasHeight/12) , that.legendBox.y+(2*that.canvasHeight/17)  );
		//that.gCanvasContext.fillText( " p + "+Math.round(that.a2*100) , that.legendBox.x+(that.canvasHeight/7) , that.legendBox.y+(2*that.canvasHeight/17.5)  );
		//that.gCanvasContext.fillText( "    1" , that.legendBox.x+(that.canvasHeight/10.5) , that.legendBox.y+(2*that.canvasHeight/20)  );
		//that.gCanvasContext.fillText( "    −" , that.legendBox.x+(that.canvasHeight/10.5) , that.legendBox.y+(2*that.canvasHeight/17)  );
		//that.gCanvasContext.fillText( "    4" , that.legendBox.x+(that.canvasHeight/10.5) , that.legendBox.y+(2*that.canvasHeight/15)  );

	}
		
	
	this.drawCanvas = function(){
		that.gCanvas.width =  that.gCanvas.width;
				
		var xPos = that.marginL;
		var yPos = that.marginT+that.availHeight;
		xNumTextHeight = 0;
		var xNumTextWidth = 0;
		
		// Grid lines along x-axis
		for(var i=0;i<that.totalSegmentsX+1;i++){
			that.drawLines(xPos,yPos+2,xPos,yPos+7,"#000",that.axisLineWidth,[]);
			if(i != 0){
				// White Grid Lines 
				that.drawLines(Math.round(xPos),Math.round(yPos),Math.round(xPos),Math.round(yPos-that.availHeight),"#00aeef",that.axisLineWidth,[]);
				
				that.gCanvasContext.fillStyle = "#000";
				that.gCanvasContext.font = that.fontSize16+"px Arial";
				
				xNumTextWidth = that.gCanvasContext.measureText( ((i)*2) ).width;
				xNumTextHeight = parseInt(that.gCanvasContext.font.match(/\d+/), 10);
				
				//console.log( parseInt(that.gCanvasContext.font.match(/\d+/), 10) );
				
				that.gCanvasContext.fillText( ((i)*2) , Math.round(xPos)-(xNumTextWidth/2) , yPos+8+xNumTextHeight  );
			}
			xPos = xPos + that.xUnitWidth;
		}
		
		var xPos = that.marginL;
		var yPos = that.marginT+that.availHeight;
		var yNumTextHeight = 0;
		var yNumTextWidth = 0;
		
		// Grid lines along y-axis
		for(var i=0;i<that.totalSegmentsY+1;i++){
			that.drawLines(xPos-2,yPos,xPos-7,yPos,"#000",that.axisLineWidth,[]);
			if(i != 0){
				// White Grid Lines 
				that.drawLines(Math.round(xPos),Math.round(yPos),Math.round(xPos+that.availWidth),Math.round(yPos),"#00aeef",that.axisLineWidth,[]);
				
				that.gCanvasContext.fillStyle = "#000";
				that.gCanvasContext.font = that.fontSize16+"px Arial"
				yNumTextWidth = that.gCanvasContext.measureText( ((i)*400) ).width;
				yNumTextHeight = parseInt(that.gCanvasContext.font.match(/\d+/), 10);
				
				that.gCanvasContext.fillText( ((i)*400) , Math.round(xPos)-(yNumTextWidth)-(that.canvasWidth/100) , yPos+(yNumTextHeight/2)-3 );
			}
			yPos = yPos - that.yUnitWidth;
		}
		
		that.drawAllLines();
		
		// x-axis
		var _x1 = that.marginL-(that.axisLineWidth/2);
		var _y1 = that.marginT+that.availHeight;
		var _x2 = that.marginL+that.availWidth+(that.axisLineWidth/2);
		var _y2 = that.marginT+that.availHeight;

		that.drawLines(_x1,_y1,_x2,_y2,"#000",that.axisLineWidth,[]);

		that.gCanvasContext.fillStyle = "#000";
		that.gCanvasContext.font = ""+that.fontSize18+"px Arial";
		var xAxisTextWidth = that.gCanvasContext.measureText("Hoeveelheid x 1000 (q)").width;
		var textHeight = parseInt(that.gCanvasContext.font.match(/\d+/), 10);
		that.gCanvasContext.fillText( "Hoeveelheid x 1000 (q)" , that.marginL+that.availWidth-xAxisTextWidth-(that.canvasWidth/8) , that.marginT+that.availHeight+6+xNumTextHeight+textHeight+20  );
		
		// y-axis
		var _x1 = that.marginL;
		var _y1 = that.marginT-(that.axisLineWidth/2);
		var _x2 = that.marginL;
		var _y2 = that.marginT+that.availHeight-(that.axisLineWidth/2);
		
		that.drawLines(_x1,_y1,_x2,_y2,"#000",that.axisLineWidth,[]);
		
		var textXpos = that.marginL ;
		var textYpos = that.marginT + that.availHeight - (6*that.yUnitWidth);
		
		that.gCanvasContext.beginPath();
		that.gCanvasContext.fillStyle = "#000";
		that.gCanvasContext.font = ""+that.fontSize18+"px Arial";
		var textWidth = that.gCanvasContext.measureText("Kosten in euro x 1000").width;
		var textHeight = parseInt(that.gCanvasContext.font.match(/\d+/), 10);
		that.gCanvasContext.fillText("Kosten in euro x 1000",textXpos-textWidth-(that.canvasWidth/60),textYpos-(that.canvasHeight/20) );

		// Draw black circle
		that.dragCircle.x = that.marginL + (that.line2Points[0].x * that.xUnitWidth);
		that.dragCircle.y = that.marginT + that.availHeight - (that.yUnitWidth*that.line2Points[0].y);
		
		// Draw blue circle
		that.dragCircle2.x = that.marginL + (that.linePoints[2].x * that.xUnitWidth);
		that.dragCircle2.y = that.marginT + that.availHeight - (that.yUnitWidth*that.a2);
		
		// Draw orange circle
		that.dragCircle3.x = that.marginL + (interSectionPoint2.x * that.xUnitWidth);;
		that.dragCircle3.y = that.marginT+that.availHeight - (interSectionPoint2.y*that.yUnitWidth);
		
		//console.log(that.dragCircle1);
		//console.log(that.dragCircle2);
		//console.log(that.dragCircle3);
		
		if(that.isOrangeCircleHighLightRequired){
			that.gCanvasContext.save();
			that.gCanvasContext.globalAlpha = 0.25;
			that.gCanvasContext.beginPath();
			that.gCanvasContext.fillStyle = '#d9953b';
			that.gCanvasContext.arc(that.dragCircle2.x,that.dragCircle2.y,that.dragCircle2.radius*2,0,2*Math.PI);
			that.gCanvasContext.fill();	
			that.gCanvasContext.restore();
		}
		
		that.gCanvasContext.beginPath();
		that.gCanvasContext.fillStyle = '#d9953b';
		that.gCanvasContext.arc(that.dragCircle2.x,that.dragCircle2.y,that.dragCircle2.radius,0,2*Math.PI);
		that.gCanvasContext.fill();
		
		if(that.isBlackCircleHighLightRequired){
			that.gCanvasContext.save();
			that.gCanvasContext.globalAlpha = 0.25;
			that.gCanvasContext.beginPath();
			that.gCanvasContext.fillStyle = '#000';
			that.gCanvasContext.arc(that.dragCircle3.x,that.dragCircle3.y,that.dragCircle3.radius*2,0,2*Math.PI);
			that.gCanvasContext.fill();	
			that.gCanvasContext.restore();
		}
		
		that.gCanvasContext.beginPath();
		that.gCanvasContext.fillStyle = '#000';
		that.gCanvasContext.arc(that.dragCircle3.x,that.dragCircle3.y,that.dragCircle3.radius,0,2*Math.PI);
		that.gCanvasContext.fill();
		
		if(that.isGreenCircleHighLightRequired){
			that.gCanvasContext.save();
			that.gCanvasContext.globalAlpha = 0.25;
			that.gCanvasContext.beginPath();
			that.gCanvasContext.fillStyle = '#70bf54';
			that.gCanvasContext.arc(that.dragCircle.x,that.dragCircle.y,that.dragCircle.radius*2,0,2*Math.PI);
			that.gCanvasContext.fill();	
			that.gCanvasContext.restore();
		}
		
		that.gCanvasContext.beginPath();
		that.gCanvasContext.fillStyle = '#70bf54';
		that.gCanvasContext.arc(that.dragCircle.x,that.dragCircle.y,that.dragCircle.radius,0,2*Math.PI);
		that.gCanvasContext.fill();
		
		that.legendBox.shown ? that.drawLegendBox() : "";
	}
	
	
	this.drawAllLines = function(){
		// Form Line between (2200,0) and (0,550)
		//                      x1 y1      x2 y2					   
		// m = (y2 - y1)/(x2-x1); ------> (550 - 0) / (0 - 2200) = -0.25;
		// y-y1 = x-x1 ; y - 0 = -0.25 * (x - 2200); ------> y = -0.25*x + 550;
		
		// Form Line with equation y = mx
		that.linePoints = [];
		
		//(x1 y1) => (0 0)
		//(x2 y2) => (2 1)
		
		that.m = (that.a2 - 0)/(2-0); 
		
		//console.log("that.totalSegmentsX: "+that.totalSegmentsX);
		
		for(var x=0;x<that.totalSegmentsX+1;x++){
			var y = that.m*x;
			that.linePoints.push({x:x,y:y});
			//console.log(y);
		}

		//console.log(that.linePoints);
		
		// Form Line with equation y = a
		that.line2Points = [];
		
		for(var x=0;x<that.totalSegmentsX+1;x++){
			var y = that.a;
			that.line2Points.push({x:x,y:y});
			//console.log(y);
		}
		
		// Form Line with equation y = mx+c 
		that.line3Points = [];
		
		for(var x=0;x<that.totalSegmentsX+1;x++){
			var y = that.m*x + that.a;
			that.line3Points.push({x:x,y:y});
			//console.log(y);
		}
		
		// Dynamic - Intersection Points 
		
		// Both the eqns solved for x and y
		interSectionPoint2.x =  Number( (that.a3).toFixed(6) );
		interSectionPoint2.y =  Number( ( (that.m*that.a3) + that.a ).toFixed(6) );
			
		//console.clear();
		//console.log(interSectionPoint2);		
				
		//Dynamic Intersection 1 coordinates
		var x1Pos = that.marginL + ( interSectionPoint2.x * that.xUnitWidth );
		var y1Pos = that.marginT + that.availHeight -(that.yUnitWidth*interSectionPoint2.y);
		
		//Dynamic Intersection 1 - Y axis coordinates 
		var x11Pos = that.marginL + ( interSectionPoint2.x * that.xUnitWidth );
		var y11Pos = that.marginT + that.availHeight;
		
		//Dynamic Intersection 1 - X axis coordinates
		var x12Pos = that.marginL;
		var y12Pos = that.marginT + that.availHeight -(that.yUnitWidth*interSectionPoint2.y);
			
		// Dynamic Vertical Dotted line - Intersection
		if(that.isDottedVL1HighLightRequired){
			that.gCanvasContext.save();
			that.gCanvasContext.globalAlpha = 0.25;
			that.drawLines(x1Pos,y1Pos,x11Pos,y11Pos,"#000",that.curveLineWidth*3,[]);	
			that.gCanvasContext.restore();
		}
		that.drawLines(x1Pos,y1Pos,x11Pos,y11Pos,"#000",that.curveLineWidth,[7,5]);
		
		// Dynamic Horizontal Dotted line - Intersection
		if(that.isDottedHLHighLightRequired){
			that.gCanvasContext.save();
			that.gCanvasContext.globalAlpha = 0.25;
			that.drawLines(x1Pos,y1Pos,x12Pos,y12Pos,"#000",that.curveLineWidth*3,[]);	
			that.gCanvasContext.restore();
		}
		that.drawLines(x1Pos,y1Pos,x12Pos,y12Pos,"#000",that.curveLineWidth,[7,5]);
				
		// Draw Line for eqn y = mx + c
		if(that.isBlueLineHighLightRequired){
			var _x1Pos = that.marginL + (that.line3Points[0].x * that.xUnitWidth);
			var _y1Pos = that.marginT + that.availHeight - (that.yUnitWidth*that.line3Points[0].y);		
			
			var _x2Pos = that.marginL + (that.line3Points[that.totalSegmentsX].x * that.xUnitWidth);
			var _y2Pos = that.marginT + that.availHeight - (that.yUnitWidth*that.line3Points[that.totalSegmentsX].y);
			
			that.gCanvasContext.save();
			that.gCanvasContext.globalAlpha = 0.25;
			that.drawLines(_x1Pos,_y1Pos,_x2Pos,_y2Pos,"#0089cf",that.curveLineWidth*3,[]);
			that.gCanvasContext.restore();
		}
		
		for(var i=0;i<that.totalSegmentsX+1;i++){
			var xPos = that.marginL + (that.line3Points[i].x * that.xUnitWidth);
			var yPos = that.marginT + that.availHeight - (that.yUnitWidth*that.line3Points[i].y);
			if(i==0){
				that.gCanvasContext.beginPath();
				that.gCanvasContext.setLineDash([]);
				that.gCanvasContext.lineWidth = that.curveLineWidth;
				that.gCanvasContext.strokeStyle = '#0089cf';
				that.gCanvasContext.moveTo(xPos,yPos);
			}else{
				that.gCanvasContext.lineTo(xPos,yPos);
			}
		}
		that.gCanvasContext.stroke();
		
		
		// Draw Line for eqn y = mx
		if(that.isOrangeLineHighLightRequired){
			var _x1Pos = that.marginL + (that.linePoints[0].x * that.xUnitWidth);
			var _y1Pos = that.marginT + that.availHeight - (that.yUnitWidth*that.linePoints[0].y);		
			
			var _x2Pos = that.marginL + (that.linePoints[that.totalSegmentsX].x * that.xUnitWidth);
			var _y2Pos = that.marginT + that.availHeight - (that.yUnitWidth*that.linePoints[that.totalSegmentsX].y);
			
			that.gCanvasContext.save();
			that.gCanvasContext.globalAlpha = 0.25;
			that.drawLines(_x1Pos,_y1Pos,_x2Pos,_y2Pos,"#d9953b",that.curveLineWidth*3,[]);
			that.gCanvasContext.restore();
		}
		
		for(var i=0;i<that.totalSegmentsX+1;i++){
			var xPos = that.marginL + (that.linePoints[i].x * that.xUnitWidth);
			var yPos = that.marginT + that.availHeight - (that.yUnitWidth*that.linePoints[i].y);
			if(i==0){
				that.gCanvasContext.beginPath();
				that.gCanvasContext.setLineDash([]);
				that.gCanvasContext.lineWidth = that.curveLineWidth;
				that.gCanvasContext.strokeStyle = '#d9953b';
				that.gCanvasContext.moveTo(xPos,yPos);
			}else{
				that.gCanvasContext.lineTo(xPos,yPos);
			}
		}
		that.gCanvasContext.stroke();
		
		// Draw Line for eqn y = a
		if(that.isGreenLineHighLightRequired){
			var _x1Pos = that.marginL + (that.line2Points[0].x * that.xUnitWidth);
			var _y1Pos = that.marginT + that.availHeight - (that.yUnitWidth*that.line2Points[0].y);		
			
			var _x2Pos = that.marginL + (that.line2Points[that.totalSegmentsX].x * that.xUnitWidth);
			var _y2Pos = that.marginT + that.availHeight - (that.yUnitWidth*that.line2Points[that.totalSegmentsX].y);
			
			that.gCanvasContext.save();
			that.gCanvasContext.globalAlpha = 0.25;
			that.drawLines(_x1Pos,_y1Pos,_x2Pos,_y2Pos,"#70bf54",that.curveLineWidth*3,[]);
			that.gCanvasContext.restore();
		}
		
		for(var i=0;i<that.totalSegmentsX+1;i++){
			var xPos = that.marginL + (that.line2Points[i].x * that.xUnitWidth);
			var yPos = that.marginT + that.availHeight - (that.yUnitWidth*that.line2Points[i].y);
			if(i==0){
				that.gCanvasContext.beginPath();
				that.gCanvasContext.setLineDash([]);
				that.gCanvasContext.lineWidth = that.curveLineWidth;
				that.gCanvasContext.strokeStyle = '#70bf54';
				that.gCanvasContext.moveTo(xPos,yPos);
			}else{
				that.gCanvasContext.lineTo(xPos,yPos);
			}
		}
		
		that.gCanvasContext.stroke();
			
				
		var textXpos = that.marginL + (7*that.xUnitWidth);
		var textYpos = that.marginT + that.availHeight - (that.yUnitWidth*that.a);
		
		that.gCanvasContext.beginPath();
		that.gCanvasContext.fillStyle = "#000";
		that.gCanvasContext.font = ""+that.fontSize18+"px Arial";
		var textWidth = that.gCanvasContext.measureText("Totale constante kosten").width;
		var textHeight = parseInt(that.gCanvasContext.font.match(/\d+/), 10);
		that.gCanvasContext.fillText("Totale constante kosten",textXpos,textYpos-(0.3*textHeight));
		
		var textXpos = that.marginL + (7*that.xUnitWidth);
		var textYpos = that.marginT + that.availHeight - (that.yUnitWidth*that.m*7);
		
		that.gCanvasContext.beginPath();
		that.gCanvasContext.fillStyle = "#000";
		that.gCanvasContext.font = ""+that.fontSize18+"px Arial";
		var textWidth = that.gCanvasContext.measureText("Totale variabele kosten").width;
		var textHeight = parseInt(that.gCanvasContext.font.match(/\d+/), 10);
		that.gCanvasContext.fillText("Totale variabele kosten",textXpos,textYpos+(textHeight));
				
		var textXpos = that.marginL + (7*that.xUnitWidth);
		var textYpos = that.marginT + that.availHeight - that.yUnitWidth*( (that.m*7) + that.a );
		
		that.gCanvasContext.beginPath();
		that.gCanvasContext.fillStyle = "#000";
		that.gCanvasContext.font = ""+that.fontSize18+"px Arial";
		var textWidth = that.gCanvasContext.measureText("Totale kosten").width;
		var textHeight = parseInt(that.gCanvasContext.font.match(/\d+/), 10);
		that.gCanvasContext.fillText("Totale kosten",textXpos,textYpos+(textHeight));
	
	}
	
	this.drawLines = function(x1,y1,x2,y2,strokeStyle,thickNess,dashesArr){
		that.gCanvasContext.beginPath();
		that.gCanvasContext.strokeStyle = strokeStyle;
		that.gCanvasContext.lineWidth = thickNess;
		that.gCanvasContext.setLineDash(dashesArr);
		that.gCanvasContext.moveTo(x1,y1);
		that.gCanvasContext.lineTo(x2,y2);
		that.gCanvasContext.stroke();	
	}
	
	this.openFullscreen = function() {
		  if(!that.isFullScreenEnabled){
				  var elem = document.getElementById("mainContainer");
				  
				  if (elem.requestFullscreen) {
					elem.requestFullscreen();
				  } else if (elem.mozRequestFullScreen) { /* Firefox */
					elem.mozRequestFullScreen();
				  } else if (elem.webkitRequestFullscreen) { /* Chrome, Safari & Opera */
					elem.webkitRequestFullscreen();
				  } else if (elem.msRequestFullscreen) { /* IE/Edge */
					console.log("msRequestFullscreen");
					elem.msRequestFullscreen();
				  }
				  
				  $("#fullScreenImage").hide();
				  $("#exitScreenImage").show();
				  
				  that.isFullScreenEnabled  = true;
		  }else{
				var elem = document;
			
				if (elem.exitFullscreen) {
					elem.exitFullscreen();
				} else if (elem.mozCancelFullScreen) { /* Firefox */
					elem.mozCancelFullScreen();
				} else if (elem.webkitExitFullscreen) { /* Chrome, Safari and Opera */
					elem.webkitExitFullscreen();
				} else if (elem.msExitFullscreen) { /* IE/Edge */
					elem.msExitFullscreen();
				}	
				
				$("#fullScreenImage").show();
				$("#exitScreenImage").hide();
				
				that.isFullScreenEnabled = false;
		  }
	}
	
	
	
}